extends RefCounted
## Сетка пикселей карты (Pixel Territory Engine).
## У каждой клетки три понятия:
##   own  — официальная принадлежность (меняется только мирным договором),
##   ctrl — кто сейчас контролирует клетку (меняется в бою),
##   since — когда контроль сменился. Если контроль чужой меньше OCC_DAYS дней, это
##   «временный военный контроль», дольше — «военная оккупация».

const SEA := 255
const OCC_DAYS := 10
const FRONT_COLOR := Color(0.04, 0.04, 0.06, 0.95)


class FrontierSet extends RefCounted:
	var arr := PackedInt32Array()
	var pos := {}

	func size() -> int:
		return arr.size()

	func add(c: int) -> void:
		if pos.has(c):
			return
		pos[c] = arr.size()
		arr.append(c)

	func remove(c: int) -> void:
		if not pos.has(c):
			return
		var i: int = pos[c]
		var last: int = arr[arr.size() - 1]
		arr[i] = last
		pos[last] = i
		arr.resize(arr.size() - 1)
		pos.erase(c)

	func random_cell(rng: RandomNumberGenerator) -> int:
		return arr[rng.randi_range(0, arr.size() - 1)]

	func clear() -> void:
		arr = PackedInt32Array()
		pos = {}


var w := 0
var h := 0
var cell := 5.0
var origin := Vector2.ZERO
var own := PackedByteArray()
var orig := PackedByteArray()
var ctrl := PackedByteArray()
var since := PackedInt32Array()
var flags := PackedByteArray()
var colors: Array = []
var counts: Array = []
var counts0: Array = []   # сколько клеток было у каждой страны в начале
var pairs := {}
var contested := {}
var annexed := {}
# области (регионы стран): фиксированное деление, при мире переходят целиком
var reg := PackedInt32Array()
var reg_n := 0
var reg_country := PackedInt32Array()   # к какой стране область относилась изначально
var reg_bbox := PackedInt32Array()      # по 4 числа на область: x0, y0, x1, y1 (в клетках)
var reg_cells := PackedInt32Array()
var reg_local := PackedInt32Array()     # номер области внутри страны
var reg_of := {}                        # страна -> сколько в ней областей
var reg_total := {}                     # страна -> клеток во всех её областях
var reg_edges_v := PackedInt32Array()
var reg_edges_h := PackedInt32Array()
var handled := {}   # страны, полностью захваченные: их заливка на карте уже перекрашена целиком
var war_a := -1
var war_d := -1
var front_a := FrontierSet.new()
var front_d := FrontierSet.new()
var held_a := 0
var held_d := 0
var dirty := PackedInt32Array()
var now := 0
var rng := RandomNumberGenerator.new()

var _qc := PackedInt32Array()
var _qd := PackedInt32Array()
var _qhead := 0


func load_file(path: String) -> bool:
	if not FileAccess.file_exists(path):
		push_error("Нет файла сетки: " + path)
		return false
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
	if typeof(parsed) != TYPE_DICTIONARY:
		return false
	w = int(parsed["w"])
	h = int(parsed["h"])
	cell = float(parsed["cell"])
	origin = Vector2(float(parsed["ox"]), float(parsed["oy"]))
	counts = []
	for v in parsed["counts"]:
		counts.append(int(v))
	counts0 = counts.duplicate()
	pairs = parsed["pairs"]
	var raw := Marshalls.base64_to_raw(parsed["rle"])
	var out := PackedByteArray()
	var i := 0
	while i + 2 < raw.size():
		var cnt: int = raw[i + 1] | (raw[i + 2] << 8)
		var chunk := PackedByteArray()
		chunk.resize(cnt)
		chunk.fill(raw[i])
		out.append_array(chunk)
		i += 3
	if out.size() != w * h:
		push_error("Сетка повреждена")
		return false
	own = out
	orig = out.duplicate()
	ctrl = out.duplicate()
	since = PackedInt32Array()
	since.resize(w * h)
	flags = PackedByteArray()
	flags.resize(w * h)
	rng.randomize()
	return true


func load_regions(path: String) -> bool:
	if not FileAccess.file_exists(path):
		push_error("Нет файла областей: " + path)
		return false
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
	if typeof(parsed) != TYPE_DICTIONARY or int(parsed["w"]) != w or int(parsed["h"]) != h:
		push_error("Файл областей не подходит к сетке")
		return false
	reg = PackedInt32Array()
	var raw := Marshalls.base64_to_raw(parsed["rle"])
	var i := 0
	while i + 3 < raw.size():
		var val: int = raw[i] | (raw[i + 1] << 8)
		var cnt: int = raw[i + 2] | (raw[i + 3] << 8)
		var chunk := PackedInt32Array()
		chunk.resize(cnt)
		chunk.fill(-1 if val == 65535 else val)
		reg.append_array(chunk)
		i += 4
	if reg.size() != w * h:
		push_error("Файл областей повреждён")
		reg = PackedInt32Array()
		return false
	reg_n = int(parsed["n"])
	reg_country.resize(reg_n)
	reg_bbox.resize(reg_n * 4)
	reg_cells.resize(reg_n)
	reg_local.resize(reg_n)
	reg_of = {}
	reg_total = {}
	for r in reg_n:
		var e: Array = parsed["regions"][r]
		var c := int(e[0])
		reg_country[r] = c
		for k in 4:
			reg_bbox[r * 4 + k] = int(e[1 + k])
		reg_cells[r] = int(e[5])
		reg_local[r] = int(e[6])
		reg_of[c] = maxi(int(reg_of.get(c, 0)), int(e[6]))
		reg_total[c] = int(reg_total.get(c, 0)) + int(e[5])
	reg_edges_v = PackedInt32Array()
	for c in parsed["ev"]:
		reg_edges_v.append(int(c))
	reg_edges_h = PackedInt32Array()
	for c in parsed["eh"]:
		reg_edges_h.append(int(c))
	return true


## Менялась ли территория страны (захваты, присоединения).
func country_changed(idx: int) -> bool:
	return idx >= 0 and idx < counts.size() and int(counts[idx]) != int(counts0[idx])


func region_at_world(p: Vector2) -> int:
	if reg.is_empty():
		return -1
	var x := int(floor((p.x - origin.x) / cell))
	var y := int(floor((p.y - origin.y) / cell))
	if x < 0 or y < 0 or x >= w or y >= h:
		return -1
	return reg[y * w + x]


## Кому сейчас принадлежит область (область всегда принадлежит одному государству).
func region_owner(r: int) -> int:
	for y in range(reg_bbox[r * 4 + 1], reg_bbox[r * 4 + 3] + 1):
		for x in range(reg_bbox[r * 4], reg_bbox[r * 4 + 2] + 1):
			var c := y * w + x
			if reg[c] == r:
				return own[c]
	return reg_country[r]


## Какие области перейдут при мире по линии фронта: больше половины области занято одной
## стороной дольше OCC_DAYS дней. Возвращает {область: кто получает}.
func region_plan() -> Dictionary:
	var occ := {}
	for c in contested.keys():
		if now - since[c] >= OCC_DAYS:
			var r: int = reg[c] if not reg.is_empty() else -1
			if r < 0:
				continue
			var k: int = ctrl[c]
			if not occ.has(r):
				occ[r] = {}
			occ[r][k] = int(occ[r].get(k, 0)) + 1
	var plan := {}
	for r in occ.keys():
		for k in occ[r].keys():
			if float(occ[r][k]) >= 0.5 * float(reg_cells[r]):
				plan[r] = k
	return plan


func _transfer_region(r: int, to: int) -> int:
	var moved := 0
	for y in range(reg_bbox[r * 4 + 1], reg_bbox[r * 4 + 3] + 1):
		for x in range(reg_bbox[r * 4], reg_bbox[r * 4 + 2] + 1):
			var c := y * w + x
			if reg[c] != r or own[c] == to:
				continue
			var prev: int = own[c]
			own[c] = to
			ctrl[c] = to
			counts[prev] = int(counts[prev]) - 1
			counts[to] = int(counts[to]) + 1
			if to == orig[c]:
				annexed.erase(c)
			else:
				annexed[c] = true
			contested.erase(c)
			dirty.append(c)
			moved += 1
	return moved


func country_at_world(p: Vector2) -> int:
	var x := int(floor((p.x - origin.x) / cell))
	var y := int(floor((p.y - origin.y) / cell))
	if x < 0 or y < 0 or x >= w or y >= h:
		return -1
	var o: int = own[y * w + x]
	return -1 if o == SEA else o


# ---------- война ----------

func begin_war(a: int, d: int) -> void:
	war_a = a
	war_d = d
	held_a = 0
	held_d = 0
	_setup_fronts()


func _setup_fronts() -> void:
	front_a.clear()
	front_d.clear()
	var key := "%d-%d" % [mini(war_a, war_d), maxi(war_a, war_d)]
	if pairs.has(key):
		for c in pairs[key]:
			_refresh_front(int(c))
	for c in annexed.keys():
		_refresh_near(int(c))
	for c in contested.keys():
		_refresh_near(int(c))


func _refresh_near(c: int) -> void:
	_refresh_front(c)
	_refresh_front(c - 1)
	_refresh_front(c + 1)
	_refresh_front(c - w)
	_refresh_front(c + w)


func _refresh_front(n: int) -> void:
	if war_a < 0 or n < 0 or n >= own.size():
		return
	var cn: int = ctrl[n]
	var in_a := false
	var in_d := false
	if cn == war_d:
		in_a = ctrl[n - 1] == war_a or ctrl[n + 1] == war_a or ctrl[n - w] == war_a or ctrl[n + w] == war_a
	elif cn == war_a:
		in_d = ctrl[n - 1] == war_d or ctrl[n + 1] == war_d or ctrl[n - w] == war_d or ctrl[n + w] == war_d
	if in_a:
		front_a.add(n)
	else:
		front_a.remove(n)
	if in_d:
		front_d.add(n)
	else:
		front_d.remove(n)
	var was := (flags[n] & 1) != 0
	var is_front := in_a or in_d
	if was != is_front:
		if is_front:
			flags[n] = flags[n] | 1
		else:
			flags[n] = flags[n] & 254
		dirty.append(n)


func capture(c: int, to: int, day: int) -> void:
	var o: int = own[c]
	if contested.has(c):
		if ctrl[c] == war_a:
			held_a -= 1
		elif ctrl[c] == war_d:
			held_d -= 1
	ctrl[c] = to
	since[c] = day
	if to != o:
		contested[c] = true
		if to == war_a:
			held_a += 1
		elif to == war_d:
			held_d += 1
		_qc.append(c)
		_qd.append(day)
	else:
		contested.erase(c)
	_refresh_near(c)
	dirty.append(c)


## Одна сторона (side_a = true: атакует A, иначе D) продвигает фронт на n клеток.
## Клетки выбираются случайно вдоль фронта, но чаще те, что окружены своими: линия получается
## неровной и естественной, без «шума».
func advance_side(side_a: bool, n: int, day: int) -> void:
	now = day
	var front: FrontierSet = front_a if side_a else front_d
	var side := war_a if side_a else war_d
	for i in n:
		if front.size() == 0:
			break
		capture(_pick(front, side), side, day)
	_promote()


func _pick(front: FrontierSet, side: int) -> int:
	var c := front.random_cell(rng)
	for attempt in 8:
		var k := 0
		if ctrl[c - 1] == side:
			k += 1
		if ctrl[c + 1] == side:
			k += 1
		if ctrl[c - w] == side:
			k += 1
		if ctrl[c + w] == side:
			k += 1
		if rng.randf() < float(k) / 4.0:
			return c
		c = front.random_cell(rng)
	return c


func _promote() -> void:
	while _qhead < _qc.size() and now - _qd[_qhead] >= OCC_DAYS:
		var c: int = _qc[_qhead]
		if contested.has(c) and since[c] == _qd[_qhead]:
			dirty.append(c)
		_qhead += 1
	if _qhead > 20000:
		_qc = _qc.slice(_qhead)
		_qd = _qd.slice(_qhead)
		_qhead = 0


func is_occupied(c: int) -> bool:
	return contested.has(c) and now - since[c] >= OCC_DAYS


func count_occupied() -> Array:
	var oa := 0
	var od := 0
	for c in contested.keys():
		if now - since[c] >= OCC_DAYS:
			if ctrl[c] == war_a:
				oa += 1
			elif ctrl[c] == war_d:
				od += 1
	return [oa, od]


func _finish_war() -> void:
	for c in front_a.arr:
		_unflag(c)
	for c in front_d.arr:
		_unflag(c)
	front_a.clear()
	front_d.clear()
	contested.clear()
	_qc = PackedInt32Array()
	_qd = PackedInt32Array()
	_qhead = 0
	held_a = 0
	held_d = 0
	war_a = -1
	war_d = -1


func _unflag(c: int) -> void:
	if (flags[c] & 1) != 0:
		flags[c] = flags[c] & 254
		dirty.append(c)


## Белый мир: всё возвращается прежним хозяевам.
func peace_white() -> void:
	for c in contested.keys():
		ctrl[c] = own[c]
		dirty.append(c)
	_finish_war()


## Мир по линии фронта. Если есть деление на области: области, занятые больше чем наполовину
## давно (OCC_DAYS дней), переходят целиком, остальное возвращается. Без областей: по клеткам.
func peace_front() -> Dictionary:
	if reg.is_empty():
		return _peace_front_cells()
	var plan := region_plan()
	var to_a := 0
	var to_d := 0
	var reg_a := 0
	var reg_d := 0
	var a := war_a
	for r in plan.keys():
		var to: int = plan[r]
		var moved := _transfer_region(int(r), to)
		if to == a:
			to_a += moved
			reg_a += 1
		else:
			to_d += moved
			reg_d += 1
	for c in contested.keys():
		ctrl[c] = own[c]
		dirty.append(c)
	_finish_war()
	_mark_bleed()
	return {"to_a": to_a, "to_d": to_d, "reg_a": reg_a, "reg_d": reg_d}


func _peace_front_cells() -> Dictionary:
	var to_a := 0
	var to_d := 0
	var a := war_a
	for c in contested.keys():
		if now - since[c] >= OCC_DAYS:
			var prev: int = own[c]
			var to: int = ctrl[c]
			own[c] = to
			counts[prev] = int(counts[prev]) - 1
			counts[to] = int(counts[to]) + 1
			if to == orig[c]:
				annexed.erase(c)
			else:
				annexed[c] = true
			if to == a:
				to_a += 1
			else:
				to_d += 1
		else:
			ctrl[c] = own[c]
		dirty.append(c)
	_finish_war()
	_mark_bleed()
	return {"to_a": to_a, "to_d": to_d, "reg_a": 0, "reg_d": 0}


## Капитуляция: вся территория проигравшего (и обособленные куски тоже) переходит победителю.
## Клетки победителя, которые успел занять враг, возвращаются ему. Возвращает число клеток.
func capitulate(winner: int, loser: int) -> int:
	handled[loser] = true
	for c in contested.keys():
		if ctrl[c] != winner:
			ctrl[c] = own[c]
			dirty.append(c)
	contested.clear()
	var moved := 0
	var i := own.find(loser, 0)
	while i != -1:
		own[i] = winner
		ctrl[i] = winner
		if winner == orig[i]:
			annexed.erase(i)
		else:
			annexed[i] = true
		dirty.append(i)
		moved += 1
		i = own.find(loser, i + 1)
	counts[winner] = int(counts[winner]) + moved
	counts[loser] = int(counts[loser]) - moved
	_finish_war()
	return moved


# ---------- рисование ----------

func color_of(c: int) -> Color:
	if (flags[c] & 1) != 0:
		return FRONT_COLOR
	var o: int = own[c]
	var k: int = ctrl[c]
	if k != o:
		var col: Color = colors[k]
		var occ := now - since[c] >= OCC_DAYS
		return Color(col.r, col.g, col.b, 0.92 if occ else 0.55)
	if o == SEA:
		return Color(0, 0, 0, 0)
	if o != orig[c]:
		if handled.has(int(orig[c])):
			return Color(0, 0, 0, 0)
		var col2: Color = colors[o]
		return Color(col2.r, col2.g, col2.b, 1.0)
	if (flags[c] & 2) != 0:
		var col3: Color = colors[o]
		return Color(col3.r, col3.g, col3.b, 1.0)
	return Color(0, 0, 0, 0)


## Клетки победителя рядом с отошедшими землями закрашиваем целиком, чтобы не просвечивала
## заливка проигравшего на стыке (клетки не совпадают с контурами страны).
func _mark_bleed() -> void:
	for key in annexed.keys():
		var c: int = key
		if handled.has(int(orig[c])):
			continue
		for off in [1, -1, w, -w]:
			var n: int = c + off
			if own[n] == own[c] and orig[n] == own[n] and (flags[n] & 2) == 0:
				flags[n] = flags[n] | 2
				dirty.append(n)


# ---------- сохранение ----------

func to_dict() -> Dictionary:
	var ann: Array = []
	for c in annexed.keys():
		ann.append(c)
		ann.append(int(own[c]))
	var con: Array = []
	for c in contested.keys():
		con.append(c)
		con.append(int(ctrl[c]))
		con.append(int(since[c]))
	return {"annexed": ann, "contested": con}


func load_state(data: Dictionary, a: int, d: int) -> void:
	var ann: Array = data.get("annexed", [])
	var i := 0
	while i + 1 < ann.size():
		var c := int(ann[i])
		var o := int(ann[i + 1])
		counts[own[c]] = int(counts[own[c]]) - 1
		counts[o] = int(counts[o]) + 1
		own[c] = o
		ctrl[c] = o
		annexed[c] = true
		dirty.append(c)
		i += 2
	_mark_bleed()
	war_a = a
	war_d = d
	held_a = 0
	held_d = 0
	var con: Array = data.get("contested", [])
	i = 0
	while i + 2 < con.size():
		var c2 := int(con[i])
		var k := int(con[i + 1])
		var s := int(con[i + 2])
		ctrl[c2] = k
		since[c2] = s
		contested[c2] = true
		dirty.append(c2)
		if k == war_a:
			held_a += 1
		elif k == war_d:
			held_d += 1
		_qc.append(c2)
		_qd.append(s)
		i += 3
	if war_a >= 0 and war_d >= 0:
		_setup_fronts()
