extends Sprite2D
## Слой пикселей захвата: одна текстура, перерисовываются только изменённые клетки.

var grid
var _img: Image
var _tex: ImageTexture
var _accum := 0.0


func setup(g) -> void:
	grid = g
	_img = Image.create(g.w, g.h, false, Image.FORMAT_RGBA8)
	_img.fill(Color(0, 0, 0, 0))
	_tex = ImageTexture.create_from_image(_img)
	texture = _tex
	centered = false
	position = g.origin
	scale = Vector2(g.cell, g.cell)
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST


func _process(delta: float) -> void:
	if grid == null:
		return
	_accum += delta
	if _accum < 0.1 or grid.dirty.is_empty():
		return
	_accum = 0.0
	var w: int = grid.w
	for c in grid.dirty:
		_img.set_pixel(c % w, c / w, grid.color_of(c))
	grid.dirty = PackedInt32Array()
	_tex.update(_img)
