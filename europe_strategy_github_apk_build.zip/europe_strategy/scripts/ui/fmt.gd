extends RefCounted
## Форматирование чисел и дат для интерфейса.

const MONTHS_SHORT := ["янв.", "февр.", "мар.", "апр.", "мая", "июн.", "июл.", "авг.", "сент.", "окт.", "нояб.", "дек."]
const NBSP := "\u00A0"


static func dec(v: float, digits: int = 1) -> String:
	return String.num(v, digits).replace(".", ",")


static func group(n: int) -> String:
	var s := str(absi(n))
	var out := ""
	var cnt := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		cnt += 1
		if cnt % 3 == 0 and i > 0:
			out = NBSP + out
	return out


static func population(n: float) -> String:
	if n >= 1000000.0:
		return dec(n / 1000000.0, 1) + " млн"
	if n >= 1000.0:
		return group(int(n / 1000.0)) + " тыс."
	return str(int(n))


static func money_bn(bn: float) -> String:
	if bn >= 1000.0:
		return "$ " + dec(bn / 1000.0, 2) + " трлн"
	if bn >= 10.0:
		return "$ " + group(int(round(bn))) + " млрд"
	return "$ " + dec(bn, 1) + " млрд"


static func rate_bn(per_day: float) -> String:
	var a := absf(per_day)
	var sign := "+" if per_day >= 0.0 else "−"
	if a >= 1.0:
		return sign + dec(a, 1) + " млрд/день"
	if a >= 0.001:
		return sign + group(int(round(a * 1000.0))) + " млн/день"
	return "0/день"


static func area_km2(v: float) -> String:
	return group(int(v)) + " км²"


static func army_k(k: float) -> String:
	if k <= 0.0:
		return "почти нет"
	return "≈ " + group(int(k)) + " тыс."


static func date_short(y: int, m: int, d: int) -> String:
	return "%d %s %d" % [d, MONTHS_SHORT[m - 1], y]
