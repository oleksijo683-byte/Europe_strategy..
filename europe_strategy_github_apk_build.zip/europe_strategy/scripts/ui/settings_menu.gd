extends Control
## Настройки графики, производительности и игры.

const UI = preload("res://scripts/ui/ui.gd")
const FPS_VALUES := [30, 60]


func _ready() -> void:
	UI.background(self)
	var box := UI.centered_box(self, 20)
	box.custom_minimum_size = Vector2(900, 0)
	box.add_child(UI.label("Настройки", 56))

	box.add_child(UI.label("Качество графики", 28, HORIZONTAL_ALIGNMENT_LEFT))
	var q := _option(["Низкое (для слабых телефонов)", "Среднее", "Высокое"])
	q.select(GameSettings.quality)
	q.item_selected.connect(_on_quality)
	box.add_child(q)

	box.add_child(UI.label("Ограничение кадров в секунду", 28, HORIZONTAL_ALIGNMENT_LEFT))
	var f := _option(["30 FPS (экономит батарею)", "60 FPS"])
	f.select(FPS_VALUES.find(GameSettings.fps_limit))
	f.item_selected.connect(_on_fps)
	box.add_child(f)

	var hints := _check("Подсказки туториала", GameSettings.hints_enabled)
	hints.toggled.connect(_on_hints)
	box.add_child(hints)

	var auto := _check("Автосохранение", GameSettings.autosave_enabled)
	auto.toggled.connect(_on_autosave)
	box.add_child(auto)

	var back := UI.button("Назад")
	back.pressed.connect(_on_back)
	box.add_child(back)


func _option(items: Array) -> OptionButton:
	var o := OptionButton.new()
	o.custom_minimum_size = Vector2(0, 80)
	o.add_theme_font_size_override("font_size", 30)
	o.get_popup().add_theme_font_size_override("font_size", 30)
	for text in items:
		o.add_item(text)
	return o


func _check(text: String, value: bool) -> CheckButton:
	var c := CheckButton.new()
	c.text = text
	c.button_pressed = value
	c.custom_minimum_size = Vector2(0, 80)
	c.add_theme_font_size_override("font_size", 30)
	return c


func _on_quality(index: int) -> void:
	GameSettings.quality = index
	GameSettings.apply()
	GameSettings.save_settings()


func _on_fps(index: int) -> void:
	GameSettings.fps_limit = FPS_VALUES[index]
	GameSettings.apply()
	GameSettings.save_settings()


func _on_hints(value: bool) -> void:
	GameSettings.hints_enabled = value
	GameSettings.save_settings()


func _on_autosave(value: bool) -> void:
	GameSettings.autosave_enabled = value
	GameSettings.save_settings()


func _on_back() -> void:
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
