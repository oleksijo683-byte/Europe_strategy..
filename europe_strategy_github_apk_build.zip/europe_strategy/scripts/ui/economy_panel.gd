extends "res://scripts/ui/panel_base.gd"
## Окно «Экономика»: вкладки Обзор, Налоги, Расходы, Финансы. (Строительство вынесено в отдельное окно.)

const Fmt = preload("res://scripts/ui/fmt.gd")

var econ
var at_war_cb: Callable
var _tabs: Array = []
var _tab_buttons: Array = []
var _vals := {}
var _steppers := {}
var _tax_info: Label
var _spend_info: Label
var _fin_info: Label
var _btn_loan: Button
var _btn_repay: Button
var _btn_print: Button
var _checks := {}
var _msg: Label


func setup(e, war_cb: Callable) -> void:
	econ = e
	at_war_cb = war_cb
	var content := build_frame("Экономика", 1500, 640)

	var bar := HBoxContainer.new()
	bar.add_theme_constant_override("separation", 12)
	var group := ButtonGroup.new()
	var names := ["Обзор", "Налоги", "Расходы", "Финансы"]
	for i in names.size():
		var b := UI.button(names[i], Vector2(300, 76))
		b.toggle_mode = true
		b.button_group = group
		b.pressed.connect(_show_tab.bind(i))
		bar.add_child(b)
		_tab_buttons.append(b)
	_box.add_child(bar)
	_box.move_child(bar, _scroll.get_index())

	for i in 4:
		var t := VBoxContainer.new()
		t.add_theme_constant_override("separation", 10)
		t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		content.add_child(t)
		_tabs.append(t)
	_build_overview(_tabs[0])
	_build_taxes(_tabs[1])
	_build_spending(_tabs[2])
	_build_finance(_tabs[3])

	_msg = UI.label("", 24, HORIZONTAL_ALIGNMENT_LEFT)
	_msg.add_theme_color_override("font_color", Color("ffb36b"))
	_box.add_child(_msg)
	_show_tab(0)


func _build_overview(t: Control) -> void:
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 40)
	grid.add_theme_constant_override("v_separation", 8)
	t.add_child(grid)
	for row in [["ВВП", "gdp"], ["Население", "pop"], ["Казна", "treasury"], ["Доходы в месяц", "income"],
			["Расходы в месяц", "expense"], ["Баланс в месяц", "balance"], ["Баланс в день", "daily"], ["Налоговая нагрузка", "burden"],
			["Инфляция", "infl"], ["Безработица", "unemp"], ["Стабильность", "stab"],
			["Экспорт (год)", "export"], ["Импорт (год)", "import"], ["Торговый баланс", "trade"]]:
		var k := UI.label(row[0], 26, HORIZONTAL_ALIGNMENT_LEFT)
		k.modulate = Color(1, 1, 1, 0.65)
		k.custom_minimum_size = Vector2(380, 0)
		grid.add_child(k)
		var v := UI.label("", 28, HORIZONTAL_ALIGNMENT_LEFT)
		grid.add_child(v)
		_vals[row[1]] = v


func _build_taxes(t: Control) -> void:
	_tax_info = UI.label("", 26, HORIZONTAL_ALIGNMENT_LEFT)
	t.add_child(_tax_info)
	_stepper(t, "Подоходный налог", "Платят граждане. Выше ставка: больше доходов, но ниже стабильность.", "t_income")
	_stepper(t, "Налог на прибыль", "Платят предприятия. Выше ставка: тормозит рост ВВП и повышает безработицу.", "t_corp")
	_stepper(t, "НДС (налог на потребление)", "Выше ставка: растут цены (инфляция), падает стабильность.", "t_vat")
	_stepper(t, "Таможенные пошлины", "Защищают рынок, но сокращают торговлю и повышают цены.", "t_tariff")


func _build_spending(t: Control) -> void:
	_spend_info = UI.label("", 26, HORIZONTAL_ALIGNMENT_LEFT)
	_spend_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_spend_info.custom_minimum_size = Vector2(1300, 0)
	t.add_child(_spend_info)
	_stepper(t, "Социальные расходы", "Выше: растёт стабильность. Ниже: растёт недовольство.", "s_social")
	_stepper(t, "Армия", "Выше: сильнее армия на войне. Ниже: слабее.", "s_mil")
	_stepper(t, "Образование и наука", "Выше: быстрее растёт ВВП (и позже ускорит исследования).", "s_edu")
	_stepper(t, "Инфраструктура", "Выше: быстрее строительство и рост ВВП.", "s_infra")


func _build_finance(t: Control) -> void:
	_fin_info = UI.label("", 26, HORIZONTAL_ALIGNMENT_LEFT)
	_fin_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_fin_info.custom_minimum_size = Vector2(1300, 0)
	t.add_child(_fin_info)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	_btn_loan = UI.button("", Vector2(520, 80))
	_btn_loan.add_theme_font_size_override("font_size", 26)
	_btn_loan.pressed.connect(_on_loan)
	row.add_child(_btn_loan)
	_btn_repay = UI.button("", Vector2(520, 80))
	_btn_repay.add_theme_font_size_override("font_size", 26)
	_btn_repay.pressed.connect(_on_repay)
	row.add_child(_btn_repay)
	t.add_child(row)
	_btn_print = UI.button("", Vector2(1056, 80))
	_btn_print.add_theme_font_size_override("font_size", 26)
	_btn_print.pressed.connect(_on_print)
	t.add_child(_btn_print)
	var pl := UI.label("Государственные программы", 30, HORIZONTAL_ALIGNMENT_LEFT)
	t.add_child(pl)
	for key in ["subsidy", "anticorr"]:
		var c := CheckButton.new()
		c.custom_minimum_size = Vector2(0, 80)
		c.add_theme_font_size_override("font_size", 26)
		c.toggled.connect(_on_policy.bind(key))
		t.add_child(c)
		_checks[key] = c


func _stepper(parent: Control, title: String, hint: String, key: String) -> void:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 2)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	var nm := UI.label(title, 28, HORIZONTAL_ALIGNMENT_LEFT)
	nm.custom_minimum_size = Vector2(500, 0)
	row.add_child(nm)
	for spec in [["−5", -0.05], ["−1", -0.01]]:
		row.add_child(_step_btn(spec[0], key, spec[1]))
	var val := UI.label("", 34)
	val.custom_minimum_size = Vector2(130, 0)
	row.add_child(val)
	for spec in [["+1", 0.01], ["+5", 0.05]]:
		row.add_child(_step_btn(spec[0], key, spec[1]))
	box.add_child(row)
	var h := UI.label(hint, 21, HORIZONTAL_ALIGNMENT_LEFT)
	h.modulate = Color(1, 1, 1, 0.6)
	box.add_child(h)
	parent.add_child(box)
	_steppers[key] = val


func _step_btn(text: String, key: String, delta: float) -> Button:
	var b := UI.button(text, Vector2(96, 72))
	b.add_theme_font_size_override("font_size", 28)
	b.pressed.connect(_on_adjust.bind(key, delta))
	return b


func _show_tab(i: int) -> void:
	for k in _tabs.size():
		_tabs[k].visible = k == i
		_tab_buttons[k].set_pressed_no_signal(k == i)
	_msg.text = ""
	if _tabs[0].is_inside_tree():
		refresh()


func show_tab(i: int) -> void:
	_show_tab(i)


func open_panel() -> void:
	_msg.text = ""
	super.open_panel()


func _on_adjust(key: String, delta: float) -> void:
	econ.adjust(key, delta)
	refresh()
	changed.emit()


func _act(err: String) -> void:
	_msg.text = err
	refresh()
	changed.emit()


func _on_loan() -> void:
	_act(econ.take_loan())


func _on_repay() -> void:
	_act(econ.repay_loan())


func _on_print() -> void:
	_act(econ.print_money())


func _on_policy(value: bool, key: String) -> void:
	econ.set_policy(key, value)
	refresh()
	changed.emit()


func _money(v: float) -> String:
	return Fmt.money_bn(v) if v >= 0.0 else "−" + Fmt.money_bn(-v)


func refresh() -> void:
	if econ == null:
		return
	var at_war: bool = at_war_cb.call()
	econ.calc_flows(at_war)
	var treasury: float = GameState.treasury_bn
	var balance: float = econ.income_m - econ.expense_m
	_vals["gdp"].text = Fmt.money_bn(econ.gdp_bn)
	_vals["pop"].text = Fmt.population(econ.pop)
	_vals["treasury"].text = _money(treasury)
	_vals["income"].text = Fmt.money_bn(econ.income_m)
	_vals["expense"].text = Fmt.money_bn(econ.expense_m)
	_vals["balance"].text = ("+" if balance >= 0.0 else "−") + Fmt.money_bn(absf(balance))
	_vals["balance"].add_theme_color_override("font_color", Color("8fd18f") if balance >= 0.0 else Color("ff8a80"))
	_vals["daily"].text = Fmt.rate_bn(balance / 30.4)
	_vals["daily"].add_theme_color_override("font_color", Color("8fd18f") if balance >= 0.0 else Color("ff8a80"))
	var burden: float = econ.raw_burden() * econ.efficiency()
	_vals["burden"].text = "%d%% ВВП" % int(round(burden * 100.0))
	_vals["infl"].text = Fmt.dec(econ.infl, 1) + "%"
	_vals["unemp"].text = Fmt.dec(econ.unemp, 1) + "%"
	_vals["stab"].text = "%d%%" % int(round(econ.stab))
	var ex: float = econ.exports_bn(at_war)
	var im: float = econ.imports_bn(at_war)
	_vals["export"].text = Fmt.money_bn(ex)
	_vals["import"].text = Fmt.money_bn(im)
	var tb := ex - im
	_vals["trade"].text = ("+" if tb >= 0.0 else "−") + Fmt.money_bn(absf(tb))
	_vals["trade"].add_theme_color_override("font_color", Color("8fd18f") if tb >= 0.0 else Color("ff8a80"))

	for key in _steppers:
		_steppers[key].text = "%d%%" % int(round(econ.get_value(key) * 100.0))
	_tax_info.text = "Налоговая нагрузка: %d%% ВВП. Поступления: %s в год." % [int(round(burden * 100.0)), Fmt.money_bn(econ.revenue_year())]
	var share: float = econ.spend_share() * 100.0
	_spend_info.text = "Расходы: %d%% доходов (+10%% управление%s). Баланс в месяц: %s%s." % [
		int(round(share)), ", +15% война" if at_war else "", "+" if balance >= 0.0 else "−", Fmt.money_bn(absf(balance))]

	_fin_info.text = "Госдолг: %s (ставка %s%%, проценты %s в год). Лимит займов: 120%% ВВП." % [
		Fmt.money_bn(econ.debt_bn), Fmt.dec(econ.debt_rate() * 100.0, 1), Fmt.money_bn(econ.interest_year())]
	_btn_loan.text = "Взять кредит (+%s)" % Fmt.money_bn(econ.loan_amount())
	_btn_repay.text = "Погасить долг (−%s)" % Fmt.money_bn(minf(econ.debt_bn, econ.loan_amount()))
	_btn_repay.disabled = econ.debt_bn <= 0.001
	_btn_print.text = "Напечатать деньги (+%s, инфляция вырастет)" % Fmt.money_bn(econ.gdp_bn * 0.01)
	_btn_print.disabled = econ.printed_this_month
	_checks["subsidy"].text = "Субсидии промышленности (%s в год): рост ВВП, меньше безработицы" % Fmt.money_bn(econ.gdp_bn * 0.004)
	_checks["anticorr"].text = "Борьба с коррупцией (%s в год): больше собираемость налогов, стабильность" % Fmt.money_bn(econ.gdp_bn * 0.002)
	for key in _checks:
		_checks[key].set_pressed_no_signal(bool(econ.policies.get(key, false)))
