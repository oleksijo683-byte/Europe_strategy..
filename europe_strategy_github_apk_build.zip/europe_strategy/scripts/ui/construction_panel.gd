extends "res://scripts/ui/panel_base.gd"
## Окно «Строительство»: заводы, электростанции, дороги, железные дороги, порты.

const Fmt = preload("res://scripts/ui/fmt.gd")
const EconomyScript = preload("res://scripts/economy/economy.gd")

var econ
var _rows := {}
var _queue_label: Label
var _msg: Label


func setup(e) -> void:
	econ = e
	var content := build_frame("Строительство", 1300, 700)
	for t in EconomyScript.ORDER:
		var r := HBoxContainer.new()
		r.add_theme_constant_override("separation", 20)
		var info := VBoxContainer.new()
		info.custom_minimum_size = Vector2(900, 0)
		var nm := UI.label("", 30, HORIZONTAL_ALIGNMENT_LEFT)
		info.add_child(nm)
		var sub := UI.label("", 22, HORIZONTAL_ALIGNMENT_LEFT)
		sub.modulate = Color(1, 1, 1, 0.65)
		info.add_child(sub)
		r.add_child(info)
		var b := UI.button("Построить", Vector2(260, 76))
		b.add_theme_font_size_override("font_size", 28)
		b.pressed.connect(_on_build.bind(t))
		r.add_child(b)
		content.add_child(r)
		_rows[t] = {"name": nm, "sub": sub, "btn": b}
	content.add_child(UI.label("Очередь строительства", 30, HORIZONTAL_ALIGNMENT_LEFT))
	_queue_label = UI.label("", 24, HORIZONTAL_ALIGNMENT_LEFT)
	_queue_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_queue_label.custom_minimum_size = Vector2(1200, 0)
	content.add_child(_queue_label)
	_msg = UI.label("", 24, HORIZONTAL_ALIGNMENT_LEFT)
	_msg.add_theme_color_override("font_color", Color("ffb36b"))
	content.add_child(_msg)


func open_panel() -> void:
	_msg.text = ""
	super.open_panel()


func _on_build(t: String) -> void:
	_msg.text = econ.start_build(t)
	refresh()
	changed.emit()


func refresh() -> void:
	if econ == null:
		return
	var treasury: float = GameState.treasury_bn
	var full: bool = econ.queue.size() >= EconomyScript.MAX_PROJECTS
	for t in EconomyScript.ORDER:
		var b: Dictionary = EconomyScript.BUILDINGS[t]
		var row: Dictionary = _rows[t]
		row["name"].text = "%s (построено: %d)" % [b["name"], int(econ.built.get(t, 0))]
		var cost: float = econ.cost_of(t)
		row["sub"].text = "%s, %d дн. Эффект: ВВП +%s%%, безработица −%s п.п." % [
			Fmt.money_bn(cost), econ.build_days(t), Fmt.dec(float(b["gdp"]) * 100.0, 1), Fmt.dec(float(b["unemp"]), 2)]
		row["btn"].disabled = full or treasury < cost
	if econ.queue.is_empty():
		_queue_label.text = "Пусто (свободных бригад: %d)" % EconomyScript.MAX_PROJECTS
	else:
		var lines: Array = []
		for p in econ.queue:
			lines.append("%s: осталось %d дн." % [EconomyScript.BUILDINGS[p["type"]]["name"], int(p["left"])])
		_queue_label.text = "\n".join(lines) + "\n(занято бригад: %d из %d)" % [econ.queue.size(), EconomyScript.MAX_PROJECTS]
