extends Control
## Экран загрузки: показывает название и полосу, затем открывает главное меню.

const UI = preload("res://scripts/ui/ui.gd")
const DURATION := 1.6

var _bar: ProgressBar
var _time := 0.0
var _done := false


func _ready() -> void:
	UI.background(self)
	var box := UI.centered_box(self, 24)
	box.add_child(UI.label("ЕВРОПА", 96))
	box.add_child(UI.label("Геополитическая стратегия", 32))
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 50)
	box.add_child(spacer)
	_bar = ProgressBar.new()
	_bar.custom_minimum_size = Vector2(700, 28)
	_bar.show_percentage = false
	_bar.max_value = 100.0
	box.add_child(_bar)
	box.add_child(UI.label("Загрузка...", 24))


func _process(delta: float) -> void:
	if _done:
		return
	_time += delta
	_bar.value = minf(_time / DURATION, 1.0) * 100.0
	if _time >= DURATION:
		_done = true
		get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
