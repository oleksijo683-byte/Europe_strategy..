extends Control
## Главное меню.

const UI = preload("res://scripts/ui/ui.gd")

var _dialog: AcceptDialog


func _ready() -> void:
	UI.background(self)
	var box := UI.centered_box(self, 22)
	box.add_child(UI.label("ЕВРОПА", 96))
	box.add_child(UI.label("Геополитическая стратегия", 32))
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 30)
	box.add_child(spacer)

	var b_continue := UI.button("Продолжить")
	b_continue.disabled = not SaveSystem.has_save()
	b_continue.pressed.connect(_on_continue)
	box.add_child(b_continue)

	var b_new := UI.button("Новая игра")
	b_new.pressed.connect(_on_new_game)
	box.add_child(b_new)

	var b_settings := UI.button("Настройки")
	b_settings.pressed.connect(_on_settings)
	box.add_child(b_settings)

	var b_exit := UI.button("Выход")
	b_exit.pressed.connect(_on_exit)
	box.add_child(b_exit)

	var version: String = str(ProjectSettings.get_setting("application/config/version", "0.0.0"))
	box.add_child(UI.label("Версия " + version, 22))

	_dialog = AcceptDialog.new()
	_dialog.title = "Сообщение"
	_dialog.ok_button_text = "ОК"
	add_child(_dialog)


func _on_continue() -> void:
	if SaveSystem.load_game():
		get_tree().change_scene_to_file("res://scenes/map_screen.tscn")
	else:
		_show("Не удалось загрузить сохранение. Начните новую игру.")


func _on_new_game() -> void:
	GameState.reset()
	get_tree().change_scene_to_file("res://scenes/map_screen.tscn")


func _on_settings() -> void:
	get_tree().change_scene_to_file("res://scenes/settings.tscn")


func _on_exit() -> void:
	get_tree().quit()


func _show(text: String) -> void:
	_dialog.dialog_text = text
	_dialog.popup_centered(Vector2i(900, 260))
