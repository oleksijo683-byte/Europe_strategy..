extends Control
## Основа окон интерфейса: затемнение, непрозрачная рамка по центру, заголовок, «Закрыть», прокрутка.

signal closed
signal changed

const UI = preload("res://scripts/ui/ui.gd")

var _panel: PanelContainer
var _box: VBoxContainer
var _scroll: ScrollContainer
var _want_w := 1400.0
var _want_h := 700.0


func build_frame(title_text: String, width: float, height: float) -> VBoxContainer:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# CenterContainer всегда держит окно по центру, независимо от его размера
	var center := CenterContainer.new()
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_panel = PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.09, 0.12, 0.18, 0.98)
	sb.border_color = Color(0.35, 0.45, 0.62)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(14)
	_panel.add_theme_stylebox_override("panel", sb)
	center.add_child(_panel)

	var pad := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		pad.add_theme_constant_override("margin_" + side, 24)
	_panel.add_child(pad)
	_box = VBoxContainer.new()
	_box.add_theme_constant_override("separation", 14)
	pad.add_child(_box)

	var head := HBoxContainer.new()
	var title := UI.label(title_text, 46, HORIZONTAL_ALIGNMENT_LEFT)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	var close_btn := UI.button("Закрыть", Vector2(240, 76))
	close_btn.pressed.connect(close_panel)
	head.add_child(close_btn)
	_box.add_child(head)

	_want_w = width
	_want_h = height
	_scroll = ScrollContainer.new()
	_scroll.custom_minimum_size = Vector2(width, height)
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	_box.add_child(_scroll)
	var content := VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 12)
	_scroll.add_child(content)

	visible = false
	return content


func open_panel() -> void:
	visible = true
	_fit_to_screen()
	refresh()


## Окно не выходит за экран: размер подгоняется под доступное место, остальное прокручивается.
func _fit_to_screen() -> void:
	var vp := get_viewport_rect().size
	_scroll.custom_minimum_size = Vector2(minf(_want_w, vp.x - 140.0), minf(_want_h, vp.y - 330.0))


func close_panel() -> void:
	if not visible:
		return
	visible = false
	closed.emit()


func refresh() -> void:
	pass
