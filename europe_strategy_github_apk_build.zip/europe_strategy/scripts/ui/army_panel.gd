extends "res://scripts/ui/panel_base.gd"
## Окно «Армия»: численность, обучение, вооружение.

const Fmt = preload("res://scripts/ui/fmt.gd")

var econ
var _vals := {}
var _btn_recruit: Button
var _btn_train: Button
var _btn_equip: Button
var _msg: Label


func setup(e) -> void:
	econ = e
	var content := build_frame("Армия", 1200, 640)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 40)
	grid.add_theme_constant_override("v_separation", 8)
	content.add_child(grid)
	for row in [["Личный состав", "staff"], ["Обучение", "train"], ["Вооружение", "equip"],
			["Качество армии", "quality"], ["Содержание в год", "upkeep"]]:
		var k := UI.label(row[0], 26, HORIZONTAL_ALIGNMENT_LEFT)
		k.modulate = Color(1, 1, 1, 0.65)
		k.custom_minimum_size = Vector2(340, 0)
		grid.add_child(k)
		var v := UI.label("", 28, HORIZONTAL_ALIGNMENT_LEFT)
		grid.add_child(v)
		_vals[row[1]] = v

	var info := UI.label("Сила армии решает исход войны: чем она выше, тем чаще продвигается ваш фронт. Расходы на армию в разделе «Расходы» экономики дают ещё до +60% к силе.", 22, HORIZONTAL_ALIGNMENT_LEFT)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.custom_minimum_size = Vector2(1100, 0)
	info.modulate = Color(1, 1, 1, 0.65)
	content.add_child(info)

	_btn_recruit = _action(content, _on_recruit)
	_btn_train = _action(content, _on_train)
	_btn_equip = _action(content, _on_equip)
	_msg = UI.label("", 24, HORIZONTAL_ALIGNMENT_LEFT)
	_msg.add_theme_color_override("font_color", Color("ffb36b"))
	content.add_child(_msg)


func _action(parent: Control, cb: Callable) -> Button:
	var b := UI.button("", Vector2(1100, 84))
	b.add_theme_font_size_override("font_size", 26)
	b.pressed.connect(cb)
	parent.add_child(b)
	return b


func open_panel() -> void:
	_msg.text = ""
	super.open_panel()


func _done(err: String) -> void:
	_msg.text = err
	refresh()
	changed.emit()


func _on_recruit() -> void:
	_done(econ.recruit())


func _on_train() -> void:
	_done(econ.upgrade_train())


func _on_equip() -> void:
	_done(econ.upgrade_equip())


func refresh() -> void:
	if econ == null:
		return
	var treasury: float = GameState.treasury_bn
	_vals["staff"].text = "%s тыс. (из них призвано: %s)" % [Fmt.group(int(round(econ.army_total_k()))), Fmt.group(int(round(econ.army_extra_k)))]
	_vals["train"].text = "уровень %d из %d (+8%% силы за уровень)" % [econ.train_lvl, econ.MAX_LVL]
	_vals["equip"].text = "уровень %d из %d (+10%% силы за уровень)" % [econ.equip_lvl, econ.MAX_LVL]
	_vals["quality"].text = "+%d%% к силе" % int(round((econ.army_quality() - 1.0) * 100.0))
	_vals["upkeep"].text = "+" + Fmt.money_bn(econ.army_upkeep_year()) + " к расходам"

	_btn_recruit.text = "Призвать резервистов: +%s тыс. (%s)" % [Fmt.group(int(round(econ.recruit_amount()))), Fmt.money_bn(econ.recruit_cost())]
	_btn_recruit.disabled = treasury < econ.recruit_cost()
	if econ.train_lvl >= econ.MAX_LVL:
		_btn_train.text = "Обучение: максимальный уровень"
		_btn_train.disabled = true
	else:
		_btn_train.text = "Улучшить обучение до уровня %d (%s)" % [econ.train_lvl + 1, Fmt.money_bn(econ.train_cost())]
		_btn_train.disabled = treasury < econ.train_cost()
	if econ.equip_lvl >= econ.MAX_LVL:
		_btn_equip.text = "Вооружение: максимальный уровень"
		_btn_equip.disabled = true
	else:
		_btn_equip.text = "Улучшить вооружение до уровня %d (%s, нужно заводов: %d)" % [econ.equip_lvl + 1, Fmt.money_bn(econ.equip_cost()), econ.equip_need_factories()]
		_btn_equip.disabled = treasury < econ.equip_cost() or int(econ.built.get("factory", 0)) < econ.equip_need_factories()
