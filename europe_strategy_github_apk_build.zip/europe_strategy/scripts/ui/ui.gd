extends RefCounted
## Небольшие помощники для построения интерфейса из кода.

static func background(parent: Control, color: Color = Color("0b1a2e")) -> void:
	var bg := ColorRect.new()
	bg.color = color
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	parent.add_child(bg)


static func label(text: String, size: int = 28, align: int = HORIZONTAL_ALIGNMENT_CENTER) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = align
	l.add_theme_font_size_override("font_size", size)
	return l


static func button(text: String, min_size: Vector2 = Vector2(520, 90)) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.add_theme_font_size_override("font_size", 32)
	return b


static func centered_box(parent: Control, separation: int = 20) -> VBoxContainer:
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	parent.add_child(center)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", separation)
	center.add_child(box)
	return box
