extends Control
## Рисует упрощённый флаг страны по описанию из data/europe_map.dat

var spec: Dictionary = {}


func _init() -> void:
	custom_minimum_size = Vector2(120, 80)
	size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	clip_contents = true
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func set_spec(s: Dictionary) -> void:
	spec = s
	queue_redraw()


func _draw() -> void:
	var r := Rect2(Vector2.ZERO, size)
	var t: String = spec.get("t", "plain")
	var c: Array = spec.get("c", ["#888888"])
	match t:
		"h":
			_stripes(r, c, spec.get("w", []), true)
		"v":
			_stripes(r, c, spec.get("w", []), false)
		"nordic":
			draw_rect(r, Color(c[0]))
			if c.size() > 2:
				_cross(r, Color(c[1]), r.size.y * 0.30)
				_cross(r, Color(c[2]), r.size.y * 0.14)
			else:
				_cross(r, Color(c[1]), r.size.y * 0.20)
		"swiss":
			draw_rect(r, Color(c[0]))
			var th := r.size.y * 0.2
			var ln := r.size.y * 0.62
			var mid := r.size / 2.0
			draw_rect(Rect2(mid.x - th / 2.0, mid.y - ln / 2.0, th, ln), Color(c[1]))
			draw_rect(Rect2(mid.x - ln / 2.0, mid.y - th / 2.0, ln, th), Color(c[1]))
		"uk":
			_uk(r)
		"tr":
			draw_rect(r, Color("#e30a17"))
			draw_circle(Vector2(r.size.x * 0.38, r.size.y * 0.5), r.size.y * 0.26, Color.WHITE)
			draw_circle(Vector2(r.size.x * 0.43, r.size.y * 0.5), r.size.y * 0.21, Color("#e30a17"))
			draw_circle(Vector2(r.size.x * 0.58, r.size.y * 0.5), r.size.y * 0.06, Color.WHITE)
		"cz":
			draw_rect(Rect2(0, 0, r.size.x, r.size.y / 2.0), Color.WHITE)
			draw_rect(Rect2(0, r.size.y / 2.0, r.size.x, r.size.y / 2.0), Color("#d7141a"))
			draw_colored_polygon(PackedVector2Array([Vector2(0, 0), Vector2(r.size.x * 0.5, r.size.y * 0.5), Vector2(0, r.size.y)]), Color("#11457e"))
		"gr":
			for i in 9:
				var col := Color("#0d5eaf") if i % 2 == 0 else Color.WHITE
				draw_rect(Rect2(0, r.size.y * i / 9.0, r.size.x, r.size.y / 9.0 + 1.0), col)
			var cs := r.size.y * 5.0 / 9.0
			draw_rect(Rect2(0, 0, cs, cs), Color("#0d5eaf"))
			var th2 := cs * 0.2
			draw_rect(Rect2(cs / 2.0 - th2 / 2.0, 0, th2, cs), Color.WHITE)
			draw_rect(Rect2(0, cs / 2.0 - th2 / 2.0, cs, th2), Color.WHITE)
		_:
			draw_rect(r, Color(c[0]))
	draw_rect(r, Color(0, 0, 0, 0.55), false, 2.0)


func _stripes(r: Rect2, colors: Array, weights: Array, horizontal: bool) -> void:
	var total := 0.0
	var ws: Array = []
	for i in colors.size():
		var w := float(weights[i]) if i < weights.size() else 1.0
		ws.append(w)
		total += w
	var pos := 0.0
	for i in colors.size():
		var frac: float = ws[i] / total
		var rect: Rect2
		if horizontal:
			rect = Rect2(r.position.x, r.position.y + pos * r.size.y, r.size.x, frac * r.size.y + 1.0)
		else:
			rect = Rect2(r.position.x + pos * r.size.x, r.position.y, frac * r.size.x + 1.0, r.size.y)
		draw_rect(rect, Color(colors[i]))
		pos += frac


func _cross(r: Rect2, col: Color, thick: float) -> void:
	var cx := r.size.x * 0.36
	draw_rect(Rect2(cx - thick / 2.0, 0, thick, r.size.y), col)
	draw_rect(Rect2(0, r.size.y / 2.0 - thick / 2.0, r.size.x, thick), col)


func _uk(r: Rect2) -> void:
	var w := r.size.x
	var h := r.size.y
	draw_rect(r, Color("#012169"))
	draw_line(Vector2(0, 0), Vector2(w, h), Color.WHITE, h * 0.22)
	draw_line(Vector2(0, h), Vector2(w, 0), Color.WHITE, h * 0.22)
	draw_line(Vector2(0, 0), Vector2(w, h), Color("#c8102e"), h * 0.08)
	draw_line(Vector2(0, h), Vector2(w, 0), Color("#c8102e"), h * 0.08)
	draw_rect(Rect2(w / 2.0 - h * 0.17, 0, h * 0.34, h), Color.WHITE)
	draw_rect(Rect2(0, h / 2.0 - h * 0.17, w, h * 0.34), Color.WHITE)
	draw_rect(Rect2(w / 2.0 - h * 0.1, 0, h * 0.2, h), Color("#c8102e"))
	draw_rect(Rect2(0, h / 2.0 - h * 0.1, w, h * 0.2), Color("#c8102e"))
