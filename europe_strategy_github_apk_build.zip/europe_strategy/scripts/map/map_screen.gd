extends Node2D
## Экран карты: выбор страны (режим "select") и игра за выбранную страну (режим "game").

const UI = preload("res://scripts/ui/ui.gd")
const Fmt = preload("res://scripts/ui/fmt.gd")
const FlagView = preload("res://scripts/ui/flag_view.gd")
const MapDataScript = preload("res://scripts/map/map_data.gd")
const MapViewScript = preload("res://scripts/map/map_view.gd")
const TerritoryGridScript = preload("res://scripts/pixel/territory_grid.gd")
const WarManagerScript = preload("res://scripts/military/war_manager.gd")
const EconomyScript = preload("res://scripts/economy/economy.gd")
const EconomyPanelScript = preload("res://scripts/ui/economy_panel.gd")
const ConstructionPanelScript = preload("res://scripts/ui/construction_panel.gd")
const ArmyPanelScript = preload("res://scripts/ui/army_panel.gd")
const MAP_FILE := "res://data/europe_map.dat"
const GRID_FILE := "res://data/europe_grid.dat"
const REGIONS_FILE := "res://data/europe_regions.dat"
const TAP_MAX_MOVE := 18.0
const TAP_MAX_MS := 450
const BUDGET_SHARE := 0.4      # доля бюджета в ВВП (игровое упрощение)
const START_TREASURY_SHARE := 0.1

var _data
var _view
var _camera: Camera2D
var _min_zoom := 0.2
var _max_zoom := 12.0
var _fit := 0.3

var _mode := "select"
var _sel := -1
var _sel_region := -1
var _player := -1

var _touches := {}
var _pinch_dist := 0.0
var _pinch_center := Vector2.ZERO
var _tap_candidate := false
var _tap_pos := Vector2.ZERO
var _tap_time := 0

var _blockers: Array = []
var _hint: Label
var _title: Label
var _btn_back: Button
var _zoom_box: VBoxContainer

var _card: PanelContainer
var _card_flag
var _card_name: Label
var _card_en: Label
var _card_status: Label
var _card_region: Label
var _card_grid: GridContainer
var _card_note: Label
var _btn_start: Button

var _top: PanelContainer
var _top_flag
var _top_name: Label
var _top_date: Label
var _top_money: Label
var _top_rate: Label
var _top_gdp: Label
var _top_pop: Label
var _top_stab: Label
var _speed_buttons: Array = []

var _dim: ColorRect
var _menu: PanelContainer
var _menu_msg: Label
var _menu_prev_speed := 0

var _grid
var _war
var _econ
var _eco_panel
var _build_panel
var _army_panel
var _btn_front: Button
var _war_view := false
var _ui_root: Control
var _bottom_bar: HBoxContainer
var _act1 := ""
var _act2 := ""
var _bact1 := ""
var _bact2 := ""
var _btn_war1: Button
var _btn_war2: Button
var _card_war_note: Label
var _war_panel: PanelContainer
var _war_title: Label
var _war_info: Label
var _war_bar: ProgressBar
var _war_b1: Button
var _war_b2: Button
var _peace: PanelContainer
var _peace_info: Label
var _toast_label: Label
var _toast_tween: Tween


func _ready() -> void:
	RenderingServer.set_default_clear_color(MapViewScript.SEA)
	_data = MapDataScript.new()
	_build_ui()
	if not _data.load_file(MAP_FILE):
		_hint.text = "Не удалось загрузить карту (data/europe_map.dat)"
		return
	_view = Node2D.new()
	_view.set_script(MapViewScript)
	add_child(_view)
	_view.setup(_data)

	_camera = Camera2D.new()
	add_child(_camera)
	_camera.make_current()
	get_viewport().size_changed.connect(_on_resized)
	_on_resized()
	_reset_view()

	GameState.day_passed.connect(_on_day)
	GameState.before_save.connect(_on_before_save)
	GameState.month_passed.connect(_on_month)
	GameState.speed_changed.connect(_sync_speed_buttons)

	if GameState.player_id != "":
		var idx: int = _view.country_index(GameState.player_id)
		if idx >= 0:
			GameState.set_speed(0)
			_player = idx
			_enter_game_mode(false)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_on_back_pressed()
	elif what == NOTIFICATION_APPLICATION_PAUSED:
		if _mode == "game" and GameSettings.autosave_enabled:
			SaveSystem.save_game()


# ---------- построение интерфейса ----------

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)
	_ui_root = root

	_btn_back = UI.button("‹ Меню", Vector2(240, 84))
	_btn_back.pressed.connect(_go_menu)
	root.add_child(_btn_back)
	_btn_back.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT, Control.PRESET_MODE_MINSIZE, 24)
	_blockers.append(_btn_back)

	_title = UI.label("Выберите страну", 44)
	_title.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	_title.add_theme_constant_override("outline_size", 8)
	_title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_title)
	_title.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 28)

	_zoom_box = VBoxContainer.new()
	_zoom_box.add_theme_constant_override("separation", 14)
	for spec in [["+", 1.6], ["−", 0.625]]:
		var b := UI.button(spec[0], Vector2(100, 100))
		b.pressed.connect(_on_zoom_button.bind(spec[1]))
		_zoom_box.add_child(b)
	var home := UI.button("⌂", Vector2(100, 100))
	home.pressed.connect(_on_home)
	_zoom_box.add_child(home)
	root.add_child(_zoom_box)
	_zoom_box.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT, Control.PRESET_MODE_MINSIZE, 24)
	_blockers.append(_zoom_box)

	_build_card(root)
	_build_topbar(root)
	_build_war_ui(root)

	_hint = UI.label("Тяни пальцем: карта двигается. Два пальца: масштаб. Тап: выбор страны.", 26)
	_hint.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	_hint.add_theme_constant_override("outline_size", 6)
	_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_hint)
	_hint.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 24)

	_build_menu(root)
	_build_peace(root)
	_build_bottom_bar(root)


func _build_card(root: Control) -> void:
	_card = PanelContainer.new()
	_card.custom_minimum_size = Vector2(660, 0)
	var pad := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		pad.add_theme_constant_override("margin_" + side, 22)
	_card.add_child(pad)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	pad.add_child(box)

	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 18)
	_card_flag = FlagView.new()
	head.add_child(_card_flag)
	var names := VBoxContainer.new()
	_card_name = UI.label("", 40, HORIZONTAL_ALIGNMENT_LEFT)
	_card_name.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_card_name.custom_minimum_size = Vector2(380, 0)
	names.add_child(_card_name)
	_card_en = UI.label("", 24, HORIZONTAL_ALIGNMENT_LEFT)
	_card_en.modulate = Color(1, 1, 1, 0.6)
	names.add_child(_card_en)
	head.add_child(names)
	box.add_child(head)

	_card_status = UI.label("", 28, HORIZONTAL_ALIGNMENT_LEFT)
	box.add_child(_card_status)
	_card_region = UI.label("", 22, HORIZONTAL_ALIGNMENT_LEFT)
	_card_region.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_card_region.custom_minimum_size = Vector2(580, 0)
	_card_region.modulate = Color(1, 1, 1, 0.75)
	box.add_child(_card_region)

	_card_grid = GridContainer.new()
	_card_grid.columns = 2
	_card_grid.add_theme_constant_override("h_separation", 24)
	_card_grid.add_theme_constant_override("v_separation", 6)
	box.add_child(_card_grid)

	_card_note = UI.label("Значения приближённые, ВВП по данным 2019 г.", 20, HORIZONTAL_ALIGNMENT_LEFT)
	_card_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_card_note.modulate = Color(1, 1, 1, 0.55)
	box.add_child(_card_note)

	_card_war_note = UI.label("", 22, HORIZONTAL_ALIGNMENT_LEFT)
	_card_war_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_card_war_note.custom_minimum_size = Vector2(580, 0)
	_card_war_note.modulate = Color(1, 0.9, 0.7, 0.95)
	box.add_child(_card_war_note)
	_btn_war1 = UI.button("", Vector2(0, 80))
	_btn_war1.add_theme_font_size_override("font_size", 28)
	_btn_war1.pressed.connect(_on_card_btn1)
	box.add_child(_btn_war1)
	_btn_war2 = UI.button("", Vector2(0, 70))
	_btn_war2.add_theme_font_size_override("font_size", 26)
	_btn_war2.pressed.connect(_on_card_btn2)
	box.add_child(_btn_war2)

	_btn_start = UI.button("Начать игру", Vector2(0, 90))
	_btn_start.pressed.connect(_on_start)
	box.add_child(_btn_start)

	_card.visible = false
	root.add_child(_card)
	_card.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 24)
	_blockers.append(_card)


func _build_topbar(root: Control) -> void:
	_top = PanelContainer.new()
	var pad := MarginContainer.new()
	pad.add_theme_constant_override("margin_left", 16)
	pad.add_theme_constant_override("margin_right", 16)
	pad.add_theme_constant_override("margin_top", 8)
	pad.add_theme_constant_override("margin_bottom", 8)
	_top.add_child(pad)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 22)
	pad.add_child(h)

	_top_flag = FlagView.new()
	_top_flag.custom_minimum_size = Vector2(72, 48)
	h.add_child(_top_flag)
	_top_name = _stat_label(h, 30)
	_top_name.custom_minimum_size = Vector2(190, 0)
	_top_name.clip_text = true
	_top_date = _stat_label(h)
	_top_money = _stat_label(h)
	_top_rate = _stat_label(h)
	var b_income := UI.button("Доход", Vector2(150, 72))
	b_income.add_theme_font_size_override("font_size", 26)
	b_income.pressed.connect(_on_income_button)
	h.add_child(b_income)
	_top_gdp = _stat_label(h)
	_top_pop = _stat_label(h)
	_top_stab = _stat_label(h)

	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(spacer)

	var group := ButtonGroup.new()
	var labels := ["II", "x1", "x2", "x5", "x10"]
	for i in labels.size():
		var b := UI.button(labels[i], Vector2(88, 72))
		b.add_theme_font_size_override("font_size", 26)
		b.toggle_mode = true
		b.button_group = group
		b.pressed.connect(_on_speed.bind(i))
		h.add_child(b)
		_speed_buttons.append(b)
	var menu := UI.button("≡", Vector2(88, 72))
	menu.pressed.connect(_open_menu)
	h.add_child(menu)

	_top.visible = false
	root.add_child(_top)
	_top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE, Control.PRESET_MODE_MINSIZE)
	_blockers.append(_top)


func _stat_label(parent: Control, size: int = 26) -> Label:
	var l := UI.label("", size, HORIZONTAL_ALIGNMENT_LEFT)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(l)
	return l


func _build_menu(root: Control) -> void:
	_dim = ColorRect.new()
	_dim.color = Color(0, 0, 0, 0.55)
	_dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	_dim.visible = false
	root.add_child(_dim)
	_blockers.append(_dim)

	_menu = PanelContainer.new()
	var pad := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		pad.add_theme_constant_override("margin_" + side, 30)
	_menu.add_child(pad)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 18)
	pad.add_child(box)
	box.add_child(UI.label("Меню игры", 46))
	var b_resume := UI.button("Продолжить")
	b_resume.pressed.connect(_close_menu)
	box.add_child(b_resume)
	var b_save := UI.button("Сохранить игру")
	b_save.pressed.connect(_on_save)
	box.add_child(b_save)
	var b_exit := UI.button("В главное меню")
	b_exit.pressed.connect(_go_menu)
	box.add_child(b_exit)
	_menu_msg = UI.label("", 24)
	box.add_child(_menu_msg)
	_menu.visible = false
	root.add_child(_menu)
	_menu.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)
	_blockers.append(_menu)


# ---------- карточка страны ----------

func _show_country(index: int) -> void:
	_sel = index
	if index < 0:
		_card.visible = false
		return
	var c: Dictionary = _data.countries[index]
	var st: Dictionary = c["stats"]
	_card_flag.set_spec(c["flag"])
	_card_name.text = c["name_ru"]
	_card_en.text = c["name"]

	if not c["playable"]:
		_card_status.text = "Недоступна для игры"
		_card_status.add_theme_color_override("font_color", Color("c0c0c0"))
	elif _mode == "game" and index == _player:
		_card_status.text = "Ваша страна"
		_card_status.add_theme_color_override("font_color", Color("ffd24d"))
	elif _mode == "game":
		_card_status.text = "Другое государство"
		_card_status.add_theme_color_override("font_color", Color("c0c0c0"))
	else:
		_card_status.text = "Доступна для игры"
		_card_status.add_theme_color_override("font_color", Color("8fd18f"))

	for ch in _card_grid.get_children():
		_card_grid.remove_child(ch)
		ch.queue_free()
	if not st.is_empty():
		var gdp: float = st["gdp_bn"]
		_add_row("Столица", st["capital"])
		_add_row("Население", Fmt.population(st["pop"]))
		_add_row("Территория", Fmt.area_km2(st["area_km2"]))
		_add_row("ВВП", Fmt.money_bn(gdp))
		_add_row("Бюджет", Fmt.money_bn(gdp * BUDGET_SHARE))
		_add_row("Армия", Fmt.army_k(st["army_k"]))
		_add_row("Строй", st["gov"])
		_add_row("Промышленность", "%d / 10" % int(st["industry"]))
		_add_row("Стабильность", "%d%%" % int(st["stability"]))
		_add_row("Блок", st["bloc"])
	_card_note.visible = not st.is_empty()
	_btn_start.visible = _mode == "select" and c["playable"]
	_card_region.text = _region_text(index)
	_card_region.visible = _card_region.text != ""
	_update_card_actions(index)
	_card.visible = true
	_card.reset_size()
	_card.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 24)


func _add_row(key: String, value: String) -> void:
	var k := UI.label(key, 24, HORIZONTAL_ALIGNMENT_LEFT)
	k.modulate = Color(1, 1, 1, 0.6)
	_card_grid.add_child(k)
	var v := UI.label(value, 26, HORIZONTAL_ALIGNMENT_LEFT)
	v.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.custom_minimum_size = Vector2(340, 0)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_card_grid.add_child(v)


# ---------- режимы ----------

func _on_start() -> void:
	if _sel < 0:
		return
	var c: Dictionary = _data.countries[_sel]
	if not c["playable"] or c["stats"].is_empty():
		return
	var budget: float = float(c["stats"]["gdp_bn"]) * BUDGET_SHARE
	GameState.new_game(c["id"], budget * START_TREASURY_SHARE)
	_player = _sel
	SaveSystem.save_game()
	_enter_game_mode(true)


func _enter_game_mode(fresh: bool) -> void:
	_mode = "game"
	GameState.active = true
	_title.visible = false
	_btn_back.visible = false
	_card.visible = false
	_view.select(-1)
	_view.set_player(_player)
	var c: Dictionary = _data.countries[_player]
	_top_flag.set_spec(c["flag"])
	_top_name.text = c["name_ru"]
	_top.visible = true
	_bottom_bar.visible = true
	_init_econ()
	_refresh_topbar()
	_sync_speed_buttons()
	_toast("Загрузка карты войны...")
	await get_tree().process_frame
	await get_tree().process_frame
	_init_war()
	_focus_country(_player)
	_hint.text = "Время на паузе. Выберите скорость справа вверху: x1, x2, x5 или x10."
	_hint.visible = true


func _refresh_topbar() -> void:
	if _player < 0:
		return
	var st: Dictionary = _data.countries[_player]["stats"]
	var gdp: float = _econ.gdp_bn if _econ != null else float(st["gdp_bn"])
	var pop: float = _econ.pop if _econ != null else float(st["pop"])
	var stab: float = _econ.stab if _econ != null else float(st["stability"])
	var money: float = GameState.treasury_bn
	_top_date.text = Fmt.date_short(GameState.year, GameState.month, GameState.day)
	_top_money.text = "Казна " + (Fmt.money_bn(money) if money >= 0.0 else "−" + Fmt.money_bn(-money))
	if _econ != null:
		_econ.calc_flows(_is_at_war())
		var per_day: float = (_econ.income_m - _econ.expense_m) / 30.4
		_top_rate.text = "(" + Fmt.rate_bn(per_day) + ")"
		_top_rate.add_theme_color_override("font_color", Color("8fd18f") if per_day >= 0.0 else Color("ff8a80"))
	_top_gdp.text = "ВВП " + Fmt.money_bn(gdp)
	_top_pop.text = "Нас. " + Fmt.population(pop)
	_top_stab.text = "Стаб. %d%%" % int(round(stab))


func _sync_speed_buttons() -> void:
	for i in _speed_buttons.size():
		_speed_buttons[i].set_pressed_no_signal(GameState.speed == GameState.SPEEDS[i])


func _on_speed(i: int) -> void:
	GameState.set_speed(GameState.SPEEDS[i])


func _open_menu() -> void:
	_menu_prev_speed = GameState.speed
	GameState.set_speed(0)
	_menu_msg.text = ""
	_dim.visible = true
	_menu.visible = true


func _close_menu() -> void:
	_dim.visible = false
	_menu.visible = false
	GameState.set_speed(_menu_prev_speed)


func _on_save() -> void:
	if SaveSystem.save_game():
		_menu_msg.text = "Игра сохранена"
	else:
		_menu_msg.text = "Не удалось сохранить"


func _on_back_pressed() -> void:
	if _eco_panel != null and _eco_panel.visible:
		_eco_panel.close_panel()
	elif _build_panel != null and _build_panel.visible:
		_build_panel.close_panel()
	elif _army_panel != null and _army_panel.visible:
		_army_panel.close_panel()
	elif _peace.visible:
		_close_peace()
	elif _mode == "game":
		if _menu.visible:
			_close_menu()
		else:
			_open_menu()
	else:
		_go_menu()


func _go_menu() -> void:
	if _mode == "game" and GameSettings.autosave_enabled:
		SaveSystem.save_game()
	GameState.active = false
	GameState.set_speed(0)
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


func _focus_country(i: int) -> void:
	var bb: Rect2 = _data.countries[i]["bbox"]
	var vp := get_viewport_rect().size
	var z := minf(vp.x * 0.45 / maxf(bb.size.x, 1.0), vp.y * 0.5 / maxf(bb.size.y, 1.0))
	z = clampf(z, _min_zoom, _fit * 6.0)
	_camera.position = bb.get_center()
	_camera.zoom = Vector2(z, z)
	_clamp_camera()
	_view.set_zoom(z)


# ---------- камера ----------

func _on_zoom_button(factor: float) -> void:
	_set_zoom_at(_camera.zoom.x * factor, get_viewport_rect().size * 0.5)


func _on_home() -> void:
	if _mode == "game" and _player >= 0:
		_focus_country(_player)
	else:
		_reset_view()


func _on_resized() -> void:
	var vp := get_viewport_rect().size
	_fit = minf(vp.x / _data.bounds.size.x, vp.y / _data.bounds.size.y)
	_min_zoom = _fit * 0.8
	_max_zoom = maxf(_fit * 30.0, 6.0)


func _reset_view() -> void:
	_camera.position = _data.bounds.get_center()
	_camera.zoom = Vector2(_fit * 0.95, _fit * 0.95)
	_view.set_zoom(_fit * 0.95)


func _clamp_camera() -> void:
	var b: Rect2 = _data.bounds
	var m := b.size * 0.05
	_camera.position.x = clampf(_camera.position.x, b.position.x - m.x, b.end.x + m.x)
	_camera.position.y = clampf(_camera.position.y, b.position.y - m.y, b.end.y + m.y)


func _pan(world_delta: Vector2) -> void:
	_camera.position += world_delta
	_clamp_camera()


func _set_zoom_at(new_zoom: float, screen_pos: Vector2) -> void:
	new_zoom = clampf(new_zoom, _min_zoom, _max_zoom)
	var half := get_viewport_rect().size * 0.5
	var world := _camera.position + (screen_pos - half) / _camera.zoom.x
	_camera.zoom = Vector2(new_zoom, new_zoom)
	_camera.position = world - (screen_pos - half) / new_zoom
	_clamp_camera()
	_view.set_zoom(new_zoom)


func _screen_to_world(screen_pos: Vector2) -> Vector2:
	var half := get_viewport_rect().size * 0.5
	return _camera.position + (screen_pos - half) / _camera.zoom.x


# ---------- ввод ----------

func _over_ui(pos: Vector2) -> bool:
	for c in _blockers:
		if c.is_visible_in_tree() and c.get_global_rect().has_point(pos):
			return true
	return false


func _unhandled_input(event: InputEvent) -> void:
	if _camera == null:
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			if _over_ui(event.position):
				return
			_hint.visible = false
			_touches[event.index] = event.position
			if _touches.size() == 1:
				_tap_candidate = true
				_tap_pos = event.position
				_tap_time = Time.get_ticks_msec()
			else:
				_tap_candidate = false
				var pts: Array = _touches.values()
				_pinch_dist = pts[0].distance_to(pts[1])
				_pinch_center = (pts[0] + pts[1]) * 0.5
		else:
			if not _touches.has(event.index):
				return
			var was_single := _touches.size() == 1
			_touches.erase(event.index)
			if was_single and _tap_candidate:
				var dt := Time.get_ticks_msec() - _tap_time
				if dt <= TAP_MAX_MS and event.position.distance_to(_tap_pos) <= TAP_MAX_MOVE:
					_select_at(event.position)
			_tap_candidate = false
			_pinch_dist = 0.0
	elif event is InputEventScreenDrag:
		if not _touches.has(event.index):
			return
		_touches[event.index] = event.position
		if _touches.size() == 1:
			if event.position.distance_to(_tap_pos) > TAP_MAX_MOVE:
				_tap_candidate = false
			_pan(-event.relative / _camera.zoom.x)
		elif _touches.size() >= 2:
			var pts: Array = _touches.values()
			var dist: float = pts[0].distance_to(pts[1])
			var center: Vector2 = (pts[0] + pts[1]) * 0.5
			if _pinch_dist > 0.0:
				_pan((_pinch_center - center) / _camera.zoom.x)
				_set_zoom_at(_camera.zoom.x * dist / _pinch_dist, center)
			_pinch_dist = dist
			_pinch_center = center
	elif event is InputEventMouseButton and event.pressed:
		if _over_ui(event.position):
			return
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			_set_zoom_at(_camera.zoom.x * 1.15, event.position)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_set_zoom_at(_camera.zoom.x / 1.15, event.position)


func _select_at(screen_pos: Vector2) -> void:
	var world := _screen_to_world(screen_pos)
	var idx := -1
	if _grid != null:
		idx = _grid.country_at_world(world)
	if idx < 0:
		idx = _view.country_at(world)
	_sel_region = -1
	if _grid != null and idx >= 0:
		_sel_region = _grid.region_at_world(world)
	_view.select(idx, _grid)
	_show_country(idx)


# ---------- войны: интерфейс ----------

func _init_war() -> void:
	if _grid != null:
		return
	_grid = TerritoryGridScript.new()
	if not _grid.load_file(GRID_FILE):
		_grid = null
		_toast("Не удалось загрузить сетку захвата (data/europe_grid.dat)")
		return
	var cols: Array = []
	for i in _data.countries.size():
		cols.append(_view.base_color(i))
	_grid.colors = cols
	_view.attach_pixels(_grid)
	if _grid.load_regions(REGIONS_FILE):
		_view.attach_regions(_grid)
		_view.attach_front(_grid)
	else:
		_toast("Области не загрузились (data/europe_regions.dat)")
	_war = WarManagerScript.new()
	_war.setup(_data, _grid, _player)
	_war.event.connect(_toast)
	_war.eliminated.connect(_on_eliminated)
	_war.territory_changed.connect(_rebuild_borders)
	_war.annexed.connect(_on_annexed)
	_sync_war_econ()
	if not GameState.war_data.is_empty():
		_war.load_dict(GameState.war_data, GameState.day_count)
		if not _grid.annexed.is_empty():
			_rebuild_borders()
	_refresh_war_ui()


func _rebuild_borders() -> void:
	if _view != null and _grid != null:
		_view.rebuild_borders(_grid, _player)


func _on_before_save() -> void:
	if _war != null:
		GameState.war_data = _war.to_dict()
	if _econ != null:
		GameState.economy_data = _econ.to_dict()


func _on_day() -> void:
	if _econ != null:
		_econ.daily()
	_refresh_topbar()
	if _war == null:
		return
	_sync_war_econ()
	_war.on_day(GameState.day_count)
	_refresh_war_ui()
	if _card.visible and _sel >= 0:
		_update_card_actions(_sel)
		_card.reset_size()
		_card.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 24)


func _build_war_ui(root: Control) -> void:
	_war_panel = PanelContainer.new()
	var pad := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		pad.add_theme_constant_override("margin_" + side, 16)
	_war_panel.add_child(pad)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	pad.add_child(box)
	_war_title = UI.label("", 28, HORIZONTAL_ALIGNMENT_LEFT)
	box.add_child(_war_title)
	_war_info = UI.label("", 22, HORIZONTAL_ALIGNMENT_LEFT)
	_war_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_war_info.custom_minimum_size = Vector2(460, 0)
	box.add_child(_war_info)
	_war_bar = ProgressBar.new()
	_war_bar.custom_minimum_size = Vector2(460, 20)
	_war_bar.show_percentage = false
	_war_bar.max_value = 100.0
	box.add_child(_war_bar)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	_war_b1 = UI.button("", Vector2(220, 66))
	_war_b1.add_theme_font_size_override("font_size", 24)
	_war_b1.pressed.connect(_on_banner_btn1)
	row.add_child(_war_b1)
	_war_b2 = UI.button("", Vector2(220, 66))
	_war_b2.add_theme_font_size_override("font_size", 24)
	_war_b2.pressed.connect(_on_banner_btn2)
	row.add_child(_war_b2)
	box.add_child(row)
	_war_panel.visible = false
	root.add_child(_war_panel)
	_blockers.append(_war_panel)

	_toast_label = UI.label("", 30)
	_toast_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.95))
	_toast_label.add_theme_constant_override("outline_size", 8)
	_toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast_label.visible = false
	root.add_child(_toast_label)


func _build_peace(root: Control) -> void:
	_peace = PanelContainer.new()
	var pad := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		pad.add_theme_constant_override("margin_" + side, 30)
	_peace.add_child(pad)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 16)
	pad.add_child(box)
	box.add_child(UI.label("Мирные переговоры", 44))
	_peace_info = UI.label("", 24, HORIZONTAL_ALIGNMENT_LEFT)
	_peace_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_peace_info.custom_minimum_size = Vector2(760, 0)
	box.add_child(_peace_info)
	var b1 := UI.button("Мир по линии фронта", Vector2(760, 90))
	b1.pressed.connect(_make_peace.bind(1))
	box.add_child(b1)
	var b2 := UI.button("Белый мир (всё возвращается)", Vector2(760, 90))
	b2.pressed.connect(_make_peace.bind(0))
	box.add_child(b2)
	var b3 := UI.button("Отмена", Vector2(760, 80))
	b3.pressed.connect(_close_peace)
	box.add_child(b3)
	_peace.visible = false
	root.add_child(_peace)
	_peace.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)
	_blockers.append(_peace)


func _toast(text: String) -> void:
	if _toast_label == null:
		return
	_toast_label.text = text
	_toast_label.visible = true
	_toast_label.modulate.a = 1.0
	_toast_label.reset_size()
	_toast_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 130)
	if _toast_tween != null:
		_toast_tween.kill()
	_toast_tween = create_tween()
	_toast_tween.tween_interval(4.0)
	_toast_tween.tween_property(_toast_label, "modulate:a", 0.0, 0.8)


func _refresh_war_ui() -> void:
	var at_war: bool = _war != null and _war.in_war()
	if _btn_front != null:
		_btn_front.visible = at_war
		if not at_war and _war_view:
			_war_view = false
			_btn_front.set_pressed_no_signal(false)
			if _view != null:
				_view.set_war_view(false)
	if _war == null:
		_war_panel.visible = false
		return
	if _war.in_war():
		_war_title.text = "Война: " + _war.name_of(_war.war_d)
		_war_info.text = "День %d. Вы заняли %d%% земель врага, враг занял %d%% ваших." % [_war.war_days(), _war.taken_by_player_pct(), _war.taken_by_enemy_pct()]
		_war_bar.visible = false
		_war_b1.text = "Мир"
		_bact1 = "peace"
		_war_b1.visible = true
		_war_b2.visible = false
		_bact2 = ""
	elif _war.is_justifying():
		_war_title.text = "Обоснование: " + _war.name_of(_war.just_target)
		if _war.just_ready:
			_war_info.text = "Война обоснована. Обоснование действует ещё %d дн." % _war.just_expire
			_war_bar.visible = false
			_war_b1.text = "Объявить войну"
			_bact1 = "declare"
			_war_b2.text = "Отменить"
			_bact2 = "cancel"
			_war_b2.visible = true
		else:
			_war_info.text = "Идёт обоснование, осталось %d дн." % _war.just_left
			_war_bar.visible = true
			_war_bar.value = 100.0 * float(WarManagerScript.JUSTIFY_DAYS - _war.just_left) / float(WarManagerScript.JUSTIFY_DAYS)
			_war_b1.text = "Отменить"
			_bact1 = "cancel"
			_war_b2.visible = false
			_bact2 = ""
		_war_b1.visible = true
	else:
		_war_panel.visible = false
		return
	_war_panel.visible = true
	_war_panel.reset_size()
	_war_panel.position = Vector2(24, 116)


func _update_card_actions(index: int) -> void:
	_btn_war1.visible = false
	_btn_war2.visible = false
	_card_war_note.visible = false
	_act1 = ""
	_act2 = ""
	if _mode != "game" or _war == null or index < 0 or index == _player:
		return
	if not _data.countries[index]["playable"]:
		return
	if _war.in_war():
		_card_war_note.visible = true
		if index == _war.war_d:
			_card_war_note.text = "С этой страной идёт война."
			_btn_war1.text = "Заключить мир"
			_btn_war1.visible = true
			_act1 = "peace"
		else:
			_card_war_note.text = "Одновременно можно вести только одну войну."
		return
	if _war.is_justifying() and _war.just_target == index:
		_card_war_note.visible = true
		if _war.just_ready:
			_card_war_note.text = "Война обоснована. Можно объявить."
			_btn_war1.text = "Объявить войну"
			_act1 = "declare"
			_btn_war2.text = "Отменить обоснование"
			_act2 = "cancel"
			_btn_war2.visible = true
		else:
			_card_war_note.text = "Идёт обоснование войны, осталось %d дн." % _war.just_left
			_btn_war1.text = "Отменить обоснование"
			_act1 = "cancel"
		_btn_war1.visible = true
		return
	var why: String = _war.block_reason(index)
	_card_war_note.visible = true
	if why != "":
		_card_war_note.text = why
		return
	_card_war_note.text = "Война начинается не сразу: её сначала нужно обосновать."
	_btn_war1.text = "Обосновать войну (%s, %d дн.)" % [Fmt.money_bn(_war.justify_cost_bn()), WarManagerScript.JUSTIFY_DAYS]
	_btn_war1.visible = true
	_act1 = "justify"


func _on_card_btn1() -> void:
	_do_action(_act1)


func _on_card_btn2() -> void:
	_do_action(_act2)


func _on_banner_btn1() -> void:
	_do_action(_bact1)


func _on_banner_btn2() -> void:
	_do_action(_bact2)


func _do_action(act: String) -> void:
	if _war == null or act == "":
		return
	var err := ""
	match act:
		"justify":
			err = _war.start_justification(_sel)
		"cancel":
			_war.cancel_justification()
		"declare":
			err = _war.declare_war()
			if err == "" and _war.in_war():
				_focus_country(_war.war_d)
				_hint.visible = false
		"peace":
			_open_peace()
			return
	if err != "":
		_toast(err)
	_refresh_topbar()
	_refresh_war_ui()
	if _sel >= 0 and _card.visible:
		_show_country(_sel)


func _open_peace() -> void:
	if _war == null or not _war.in_war():
		return
	_menu_prev_speed = GameState.speed
	GameState.set_speed(0)
	var occ: Array = _grid.count_occupied()
	var plan: Dictionary = _grid.region_plan()
	var ra := 0
	var rd := 0
	for r in plan.keys():
		if plan[r] == _grid.war_a:
			ra += 1
		else:
			rd += 1
	_peace_info.text = "Противник: %s. Вы удерживаете %d участков (оккупировано дольше %d дней: %d), враг удерживает %d (оккупировано: %d).\n\nМир по линии фронта: области, где больше половины земель давно заняты одной стороной, переходят целиком. Сейчас вы получили бы областей: %d, потеряли бы: %d. Остальное возвращается. Белый мир: всё как было." % [
		_war.name_of(_war.war_d), _grid.held_a, TerritoryGridScript.OCC_DAYS, occ[0], _grid.held_d, occ[1], ra, rd]
	_dim.visible = true
	_peace.visible = true
	_peace.reset_size()
	_peace.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)


func _close_peace() -> void:
	_peace.visible = false
	_dim.visible = false
	GameState.set_speed(_menu_prev_speed)


func _make_peace(mode: int) -> void:
	_peace.visible = false
	_dim.visible = false
	if _war != null:
		_war.make_peace(mode)
	GameState.set_speed(_menu_prev_speed)
	_refresh_war_ui()
	if _sel >= 0:
		_show_country(_sel)


# ---------- экономика и строительство ----------

func _init_econ() -> void:
	if _econ != null:
		return
	_econ = EconomyScript.new()
	var st: Dictionary = _data.countries[_player]["stats"]
	if GameState.economy_data.is_empty():
		_econ.init_from_stats(st)
	else:
		_econ.load_dict(GameState.economy_data)
	_econ.event.connect(_toast)
	_eco_panel = EconomyPanelScript.new()
	_ui_root.add_child(_eco_panel)
	_eco_panel.setup(_econ, _is_at_war)
	_build_panel = ConstructionPanelScript.new()
	_ui_root.add_child(_build_panel)
	_build_panel.setup(_econ)
	_army_panel = ArmyPanelScript.new()
	_ui_root.add_child(_army_panel)
	_army_panel.setup(_econ)
	for p in [_eco_panel, _build_panel, _army_panel]:
		p.closed.connect(_on_panel_closed)
		p.changed.connect(_on_economy_changed)
		_blockers.append(p)
	# кнопки меню поверх окон: повторное нажатие закрывает окно
	_ui_root.move_child(_bottom_bar, -1)


func _is_at_war() -> bool:
	return _war != null and _war.in_war()


func _build_bottom_bar(root: Control) -> void:
	_bottom_bar = HBoxContainer.new()
	_bottom_bar.add_theme_constant_override("separation", 14)
	_btn_front = UI.button("Фронт", Vector2(200, 84))
	_btn_front.toggle_mode = true
	_btn_front.pressed.connect(_on_front_button)
	_btn_front.visible = false
	_bottom_bar.add_child(_btn_front)
	var b_army := UI.button("Армия", Vector2(220, 84))
	b_army.pressed.connect(_on_army_button)
	_bottom_bar.add_child(b_army)
	var b_eco := UI.button("Экономика", Vector2(280, 84))
	b_eco.pressed.connect(_on_eco_button)
	_bottom_bar.add_child(b_eco)
	var b_build := UI.button("Строительство", Vector2(320, 84))
	b_build.pressed.connect(_on_build_button)
	_bottom_bar.add_child(b_build)
	_bottom_bar.visible = false
	root.add_child(_bottom_bar)
	_bottom_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 24)
	_bottom_bar.position.y = 116.0
	_blockers.append(_bottom_bar)


func _on_eco_button() -> void:
	_toggle_panel(_eco_panel)


## «Доход»: открывает экономику на вкладке «Налоги» (повторное нажатие закрывает).
func _on_income_button() -> void:
	if _eco_panel == null:
		return
	if _eco_panel.visible:
		_eco_panel.close_panel()
		return
	_toggle_panel(_eco_panel)
	_eco_panel.show_tab(1)


func _on_army_button() -> void:
	_toggle_panel(_army_panel)


## Режим фронта: линия фронта, красные и синие точки, армии-кольца (как на референсе).
func _on_front_button() -> void:
	_war_view = _btn_front.button_pressed
	_view.set_war_view(_war_view)
	_update_front_rings()
	if _war_view:
		_focus_front()
		_hint.text = "Режим фронта: синие точки ваши войска, красные противника. Кнопка «Фронт» выключает режим."
		_hint.visible = true


func _update_front_rings() -> void:
	if _war == null or _econ == null or _view == null or not _war.in_war():
		return
	var mine := int(_econ.army_total_k() / 25.0)
	var st: Dictionary = _data.countries[_war.war_d]["stats"]
	var enemy := int(float(st.get("army_k", 25)) / 25.0)
	_view.set_front_rings(mine, enemy)


func _focus_front() -> void:
	if _grid == null:
		return
	var min_x := 1.0e12
	var min_y := 1.0e12
	var max_x := -1.0e12
	var max_y := -1.0e12
	for arr in [_grid.front_a.arr, _grid.front_d.arr]:
		for c in arr:
			var px: float = _grid.origin.x + float(c % _grid.w) * _grid.cell
			var py: float = _grid.origin.y + float(int(c / _grid.w)) * _grid.cell
			min_x = minf(min_x, px)
			max_x = maxf(max_x, px)
			min_y = minf(min_y, py)
			max_y = maxf(max_y, py)
	if min_x > max_x:
		return
	var vp := get_viewport_rect().size
	var sx: float = maxf(max_x - min_x + 240.0, 1.0)
	var sy: float = maxf(max_y - min_y + 240.0, 1.0)
	var z := clampf(minf(vp.x * 0.8 / sx, vp.y * 0.7 / sy), _min_zoom, _fit * 8.0)
	_camera.position = Vector2((min_x + max_x) * 0.5, (min_y + max_y) * 0.5)
	_camera.zoom = Vector2(z, z)
	_clamp_camera()
	_view.set_zoom(z)


func _on_build_button() -> void:
	_toggle_panel(_build_panel)


func _toggle_panel(p) -> void:
	if p == null:
		return
	if p.visible:
		p.close_panel()
		return
	for q in [_eco_panel, _build_panel, _army_panel]:
		if q != p and q.visible:
			q.close_panel()
	_menu_prev_speed = GameState.speed
	GameState.set_speed(0)
	p.open_panel()


func _on_panel_closed() -> void:
	GameState.set_speed(_menu_prev_speed)
	_sync_war_econ()
	_refresh_topbar()


func _on_economy_changed() -> void:
	_sync_war_econ()
	_refresh_topbar()


func _sync_war_econ() -> void:
	if _war == null or _econ == null:
		return
	_war.player_budget_bn = _econ.revenue_year()
	_war.player_stab = _econ.stab
	_war.player_mil = _econ.mil_factor()
	_war.player_army_k = _econ.army_total_k()
	_war.player_quality = _econ.army_quality()
	_update_front_rings()


func _on_month() -> void:
	if _econ == null:
		return
	_econ.monthly(_is_at_war())
	_sync_war_econ()
	_refresh_topbar()


func _on_annexed(loser_idx: int, fraction: float) -> void:
	if _econ == null:
		return
	var st: Dictionary = _data.countries[loser_idx]["stats"]
	if not st.is_empty():
		_econ.add_conquered(float(st["gdp_bn"]), float(st["pop"]), fraction)
	_refresh_topbar()


func _on_eliminated(idx: int) -> void:
	_view.set_eliminated(idx)
	_view.recolor_country(idx, _view.base_color(_player), _player)


func _region_text(index: int) -> String:
	if _grid == null or _sel_region < 0 or index < 0 or _grid.reg_n == 0:
		return ""
	var r := _sel_region
	var rc: int = _grid.reg_country[r]
	var of: int = int(_grid.reg_of.get(rc, 1))
	var txt := "Область %d из %d" % [_grid.reg_local[r], of]
	if rc != index:
		txt += " (бывшая территория: %s)" % _data.countries[rc]["name_ru"]
	else:
		var total: int = maxi(1, int(_grid.reg_total.get(rc, 1)))
		txt += ", %s%% территории страны" % Fmt.dec(100.0 * float(_grid.reg_cells[r]) / float(total), 1)
	return txt
