extends RefCounted
## Данные карты: страны, контуры, треугольники. Файл готовит tools/build_map.py

var bounds := Rect2()
var countries: Array = []


func load_file(path: String) -> bool:
	if not FileAccess.file_exists(path):
		push_error("Нет файла карты: " + path)
		return false
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
	if typeof(parsed) != TYPE_DICTIONARY:
		push_error("Файл карты повреждён")
		return false
	var b: Array = parsed["bounds"]
	bounds = Rect2(b[0], b[1], b[2] - b[0], b[3] - b[1])
	countries.clear()
	for c in parsed["countries"]:
		var polys: Array = []
		var bbox := Rect2()
		var has_bbox := false
		for p in c["polys"]:
			var v: Array = p["v"]
			var ring := PackedVector2Array()
			ring.resize(int(v.size() * 0.5))
			for i in ring.size():
				ring[i] = Vector2(v[2 * i], v[2 * i + 1])
			var tris := PackedInt32Array()
			for t in p["t"]:
				tris.append(int(t))
			polys.append({"ring": ring, "tris": tris})
			for pt in ring:
				if has_bbox:
					bbox = bbox.expand(pt)
				else:
					bbox = Rect2(pt, Vector2.ZERO)
					has_bbox = true
		var lab: Array = c["label"]
		countries.append({
			"id": c["id"],
			"name": c["name"],
			"name_ru": c["name_ru"],
			"playable": c["playable"],
			"color": int(c["color"]),
			"hex": str(c.get("hex", "")),
			"stats": c.get("stats", {}),
			"flag": c.get("flag", {}),
			"neighbors": c.get("neighbors", []),
			"area": float(c["area"]),
			"label": Vector2(lab[0], lab[1]),
			"polys": polys,
			"bbox": bbox,
		})
	return true


func index_of(id: String) -> int:
	for i in countries.size():
		if countries[i]["id"] == id:
			return i
	return -1
