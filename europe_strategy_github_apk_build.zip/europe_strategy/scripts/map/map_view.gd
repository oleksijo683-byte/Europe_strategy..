extends Node2D
## Рисует карту: заливка стран (меши), границы, подписи, подсветка выбранной страны.

const SEA := Color("0e2a47")
const LAND_OTHER := Color(0.36, 0.37, 0.38)
const PALETTE := [
	Color("b06060"), Color("5f8cb0"), Color("96aa5a"), Color("bf9d50"),
	Color("8a6aa8"), Color("5aa08c"), Color("c8784a"), Color("789878"),
]
const BORDER_COLOR := Color(0.05, 0.06, 0.08, 0.95)
const SELECT_COLOR := Color(1.0, 1.0, 0.85, 1.0)
const PLAYER_COLOR := Color(1.0, 0.8, 0.2, 1.0)
const STAR_MIN_ZOOM := 0.5
const COLOR_MINE := Color(0.18, 0.28, 0.98)
const COLOR_ENEMY := Color(0.95, 0.12, 0.12)
const COLOR_DARK := Color(0.02, 0.03, 0.12)
const FRONT_STEP := 5.0
const REGION_MIN_ZOOM := 0.55
const REGION_COLOR := Color(0.0, 0.0, 0.0, 0.38)
const PixelLayerScript = preload("res://scripts/pixel/pixel_layer.gd")

var data
var zoom := 0.3
var selected := -1
var player := -1

var _meshes: Array = []
var _base_colors: Array = []
var _closed: Array = []
var _labels: Array = []
var _borders: Node2D
var _label_root: Node2D
var _caps: Node2D
var pixel_layer
var _region_node: Node2D
var _lit: Array = []
var _sel_segs := PackedVector2Array()
var _recolored := {}   # побеждённая страна -> кто её захватил
var war_view := false
var _front_node: Node2D
var _front_grid
var _front_dots: Array = []
var _front_rings: Array = []
var _front_cities := PackedVector2Array()
var _front_timer := 0.0
var _rings_mine := 4
var _rings_enemy := 4
var _region_segs := PackedVector2Array()
var _eliminated := {}
var _use_segments := false
var _seg_normal := PackedVector2Array()
var _seg_gold := PackedVector2Array()


func setup(map_data) -> void:
	data = map_data
	for i in data.countries.size():
		var c: Dictionary = data.countries[i]
		var col: Color = LAND_OTHER
		if c["playable"]:
			if c["hex"] != "":
				col = Color(c["hex"])
			elif c["color"] >= 0:
				col = PALETTE[c["color"] % PALETTE.size()]
		_base_colors.append(col)

		var verts := PackedVector2Array()
		var idx := PackedInt32Array()
		var closed_rings: Array = []
		for poly in c["polys"]:
			var base := verts.size()
			verts.append_array(poly["ring"])
			for t in poly["tris"]:
				idx.append(base + t)
			var ring: PackedVector2Array = poly["ring"].duplicate()
			ring.append(ring[0])
			closed_rings.append(ring)
		_closed.append(closed_rings)

		var arrays := []
		arrays.resize(Mesh.ARRAY_MAX)
		arrays[Mesh.ARRAY_VERTEX] = verts
		arrays[Mesh.ARRAY_INDEX] = idx
		var mesh := ArrayMesh.new()
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
		var mi := MeshInstance2D.new()
		mi.mesh = mesh
		mi.modulate = col
		add_child(mi)
		_meshes.append(mi)

	_borders = Node2D.new()
	add_child(_borders)
	_borders.draw.connect(_draw_borders)

	_caps = Node2D.new()
	add_child(_caps)
	_caps.draw.connect(_draw_caps)

	_label_root = Node2D.new()
	add_child(_label_root)
	for i in data.countries.size():
		var c: Dictionary = data.countries[i]
		if not c["playable"]:
			continue
		var l := Label.new()
		l.text = c["name_ru"]
		l.add_theme_font_size_override("font_size", 24)
		l.add_theme_color_override("font_color", Color(1, 1, 1, 0.95))
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
		l.add_theme_constant_override("outline_size", 6)
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_label_root.add_child(l)
		l.size = l.get_minimum_size()
		_labels.append({
			"idx": i, "label": l, "pos": c["label"], "size": l.size, "width": l.size.x, "area": c["area"],
		})
	set_zoom(zoom)


func set_zoom(z: float) -> void:
	zoom = z
	var inv := 1.0 / zoom
	for item in _labels:
		var l: Label = item["label"]
		var px: float = sqrt(item["area"]) * zoom
		l.visible = px >= float(item["width"]) * 0.75 and not _eliminated.has(item["idx"])
		l.scale = Vector2(inv, inv)
		l.position = item["pos"] - item["size"] * inv * 0.5
	_borders.queue_redraw()
	_caps.queue_redraw()
	if _region_node != null:
		_region_node.queue_redraw()
	if _front_node != null:
		_front_node.queue_redraw()


func set_player(index: int) -> void:
	player = index
	_borders.queue_redraw()


func country_index(id: String) -> int:
	for i in data.countries.size():
		if data.countries[i]["id"] == id:
			return i
	return -1


func select(index: int, grid = null) -> void:
	for i in _lit:
		_meshes[i].modulate = _base_colors[i]
	_lit = []
	selected = index
	_sel_segs = PackedVector2Array()
	if selected >= 0:
		_lit.append(selected)
		for k in _recolored.keys():
			if _recolored[k] == selected:
				_lit.append(k)
		for i in _lit:
			_meshes[i].modulate = _base_colors[i].lightened(0.3)
		if grid != null and grid.country_changed(selected):
			_sel_segs = _country_outline(grid, selected)
	_borders.queue_redraw()


## Контур всей нынешней территории страны (с учётом захваченных земель) по клеткам.
func _country_outline(grid, idx: int) -> PackedVector2Array:
	var segs := PackedVector2Array()
	var cs: float = grid.cell
	var w: int = grid.w
	var o: Vector2 = grid.origin
	var own = grid.own
	var c: int = own.find(idx, 0)
	while c != -1:
		var x: int = c % w
		var y: int = int(c / w)
		var bx: float = o.x + float(x) * cs
		var by: float = o.y + float(y) * cs
		if own[c + 1] != idx:
			segs.append(Vector2(bx + cs, by))
			segs.append(Vector2(bx + cs, by + cs))
		if own[c - 1] != idx:
			segs.append(Vector2(bx, by))
			segs.append(Vector2(bx, by + cs))
		if own[c + w] != idx:
			segs.append(Vector2(bx, by + cs))
			segs.append(Vector2(bx + cs, by + cs))
		if own[c - w] != idx:
			segs.append(Vector2(bx, by))
			segs.append(Vector2(bx + cs, by))
		c = own.find(idx, c + 1)
	return segs


func country_at(p: Vector2) -> int:
	for i in data.countries.size():
		var c: Dictionary = data.countries[i]
		if not c["bbox"].has_point(p):
			continue
		for poly in c["polys"]:
			if Geometry2D.is_point_in_polygon(p, poly["ring"]):
				return i
	return -1


func _draw_borders() -> void:
	var w := 1.4 / zoom
	var aa: bool = GameSettings.quality >= 1
	if _use_segments:
		if _seg_normal.size() > 0:
			_borders.draw_multiline(_seg_normal, BORDER_COLOR, w, aa)
		if _seg_gold.size() > 0:
			_borders.draw_multiline(_seg_gold, PLAYER_COLOR, 3.0 / zoom, aa)
	else:
		for ci in _closed.size():
			if _eliminated.has(ci):
				continue
			for ring in _closed[ci]:
				_borders.draw_polyline(ring, BORDER_COLOR, w, aa)
		if player >= 0:
			for ring in _closed[player]:
				_borders.draw_polyline(ring, PLAYER_COLOR, 3.0 / zoom, aa)
	if not _sel_segs.is_empty():
		_borders.draw_multiline(_sel_segs, SELECT_COLOR, 3.5 / zoom, aa)
	elif selected >= 0:
		for ring in _closed[selected]:
			_borders.draw_polyline(ring, SELECT_COLOR, 3.5 / zoom, aa)


## Пересчитывает границы по тому, кому реально принадлежат клетки. Вызывается после мирного
## договора и капитуляции: внутренние границы захваченных земель исчезают, новые появляются.
func rebuild_borders(grid, player_idx: int) -> void:
	_use_segments = true
	player = player_idx
	var changed := {}
	for key in grid.annexed.keys():
		changed[int(grid.orig[key])] = true
		changed[int(grid.own[key])] = true
	_seg_normal = PackedVector2Array()
	_seg_gold = PackedVector2Array()
	var off := 6.0
	for ci in _closed.size():
		var eval_ring: bool = changed.has(ci)
		var is_player: bool = ci == player_idx
		for ring in _closed[ci]:
			for i in range(ring.size() - 1):
				var a: Vector2 = ring[i]
				var b: Vector2 = ring[i + 1]
				var seg_len := a.distance_to(b)
				if seg_len < 0.001:
					continue
				var k := maxi(1, int(ceil(seg_len / 10.0)))
				for j in k:
					var p0 := a.lerp(b, float(j) / float(k))
					var p1 := a.lerp(b, float(j + 1) / float(k))
					if eval_ring:
						var nrm := Vector2(-(p1.y - p0.y), p1.x - p0.x).normalized()
						var mid := (p0 + p1) * 0.5
						var o1: int = grid.country_at_world(mid + nrm * off)
						var o2: int = grid.country_at_world(mid - nrm * off)
						if o1 == o2 and o1 >= 0:
							continue
						if o1 == player_idx or o2 == player_idx:
							_seg_gold.append(p0)
							_seg_gold.append(p1)
						else:
							_seg_normal.append(p0)
							_seg_normal.append(p1)
					elif is_player:
						_seg_gold.append(p0)
						_seg_gold.append(p1)
					else:
						_seg_normal.append(p0)
						_seg_normal.append(p1)
	# новые границы внутри бывших стран (часть земель отошла по мирному договору)
	var cs: float = grid.cell
	var gw: int = grid.w
	var neigh := [1, -1, gw, -gw]
	for key in grid.annexed.keys():
		var c: int = key
		var x: int = c % gw
		var y: int = int(c / gw)
		var oc: int = grid.own[c]
		for d in 4:
			var n: int = c + neigh[d]
			var on: int = grid.own[n]
			if on == 255 or on == oc or grid.orig[n] != grid.orig[c]:
				continue
			var q0 := Vector2.ZERO
			var q1 := Vector2.ZERO
			var bx: float = grid.origin.x + float(x) * cs
			var by: float = grid.origin.y + float(y) * cs
			match d:
				0:
					q0 = Vector2(bx + cs, by)
					q1 = Vector2(bx + cs, by + cs)
				1:
					q0 = Vector2(bx, by)
					q1 = Vector2(bx, by + cs)
				2:
					q0 = Vector2(bx, by + cs)
					q1 = Vector2(bx + cs, by + cs)
				_:
					q0 = Vector2(bx, by)
					q1 = Vector2(bx + cs, by)
			if oc == player_idx or on == player_idx:
				_seg_gold.append(q0)
				_seg_gold.append(q1)
			else:
				_seg_normal.append(q0)
				_seg_normal.append(q1)
	_borders.queue_redraw()


func _draw_caps() -> void:
	if zoom < STAR_MIN_ZOOM:
		return
	var r := 9.0 / zoom
	for ci in data.countries.size():
		if _eliminated.has(ci):
			continue
		var st: Dictionary = data.countries[ci]["stats"]
		if not st.has("cap"):
			continue
		var p := Vector2(st["cap"][0], st["cap"][1])
		var pts := PackedVector2Array()
		for i in 10:
			var a := -PI / 2.0 + float(i) * PI / 5.0
			var rad := r if i % 2 == 0 else r * 0.42
			pts.append(p + Vector2(cos(a), sin(a)) * rad)
		_caps.draw_colored_polygon(pts, Color(1.0, 0.85, 0.2))


func set_eliminated(i: int) -> void:
	_eliminated[i] = true
	set_zoom(zoom)
	_caps.queue_redraw()


## Полностью захваченная страна перекрашивается в цвет победителя (никаких остатков прежнего цвета).
func recolor_country(i: int, col: Color, winner: int = -1) -> void:
	_base_colors[i] = col
	_meshes[i].modulate = col
	if winner >= 0:
		_recolored[i] = winner


## Тонкие границы областей внутри стран (видны при приближении).
func attach_regions(grid) -> void:
	_region_segs = PackedVector2Array()
	var cs: float = grid.cell
	var gw: int = grid.w
	for c in grid.reg_edges_v:
		var x: int = c % gw
		var y: int = int(c / gw)
		var bx: float = grid.origin.x + float(x + 1) * cs
		var by: float = grid.origin.y + float(y) * cs
		_region_segs.append(Vector2(bx, by))
		_region_segs.append(Vector2(bx, by + cs))
	for c in grid.reg_edges_h:
		var x2: int = c % gw
		var y2: int = int(c / gw)
		var bx2: float = grid.origin.x + float(x2) * cs
		var by2: float = grid.origin.y + float(y2 + 1) * cs
		_region_segs.append(Vector2(bx2, by2))
		_region_segs.append(Vector2(bx2 + cs, by2))
	if _region_node == null:
		_region_node = Node2D.new()
		add_child(_region_node)
		move_child(_region_node, _borders.get_index())
		_region_node.draw.connect(_draw_regions)
	_region_node.queue_redraw()


func _draw_regions() -> void:
	if zoom < REGION_MIN_ZOOM or _region_segs.is_empty():
		return
	_region_node.draw_multiline(_region_segs, REGION_COLOR, 1.0 / zoom, false)


## Режим фронта: красные и синие точки вдоль линии фронта, кольца-армии позади, жёлтые точки-города.
func attach_front(grid) -> void:
	_front_grid = grid
	_front_node = Node2D.new()
	add_child(_front_node)
	move_child(_front_node, _label_root.get_index())
	_front_node.draw.connect(_draw_front)
	_front_node.visible = false
	_front_cities = PackedVector2Array()
	var cs: float = grid.cell
	for r in grid.reg_n:
		var cx: float = float(grid.reg_bbox[r * 4] + grid.reg_bbox[r * 4 + 2]) * 0.5
		var cy: float = float(grid.reg_bbox[r * 4 + 1] + grid.reg_bbox[r * 4 + 3]) * 0.5
		_front_cities.append(grid.origin + Vector2((cx + 0.5) * cs, (cy + 0.5) * cs))
	set_process(false)


func set_war_view(on: bool) -> void:
	war_view = on
	if _front_node == null:
		return
	_front_node.visible = on
	set_process(on)
	if on:
		rebuild_front()


func set_front_rings(mine: int, enemy: int) -> void:
	_rings_mine = clampi(mine, 2, 24)
	_rings_enemy = clampi(enemy, 2, 24)


func _process(delta: float) -> void:
	if not war_view:
		return
	_front_timer += delta
	if _front_timer >= 0.4:
		_front_timer = 0.0
		rebuild_front()


func rebuild_front() -> void:
	_front_dots = []
	_front_rings = []
	var g = _front_grid
	if g != null and g.war_a >= 0 and g.war_d >= 0 and g.front_d.size() > 0:
		_build_front(g)
	_front_node.queue_redraw()


## Строит сплошную линию фронта из границ между клетками, сглаживает её и ставит точки
## с равным шагом по обе стороны (только на своей территории), а позади кольца-армии.
func _build_front(g) -> void:
	var w: int = g.w
	var ww: int = w + 1
	var ea := PackedInt32Array()
	var eb := PackedInt32Array()
	var adj := {}
	for c in g.front_d.arr:
		var x: int = c % w
		var y: int = int(c / w)
		var k00: int = y * ww + x
		var k10: int = k00 + 1
		var k01: int = k00 + ww
		var k11: int = k01 + 1
		if g.ctrl[c + 1] == g.war_d:
			_add_edge(ea, eb, adj, k10, k11)
		if g.ctrl[c - 1] == g.war_d:
			_add_edge(ea, eb, adj, k00, k01)
		if g.ctrl[c + w] == g.war_d:
			_add_edge(ea, eb, adj, k01, k11)
		if g.ctrl[c - w] == g.war_d:
			_add_edge(ea, eb, adj, k00, k10)
	var chains: Array = _chain_edges(ea, eb, adj)
	var cs: float = g.cell
	var cand_mine: Array = []
	var cand_enemy: Array = []
	for chain in chains:
		if chain.size() < 6:
			continue
		var path := PackedVector2Array()
		for k in chain:
			path.append(Vector2(float(k % ww), float(int(k / ww))))
		path = _smooth_path(path, 3)
		var pts: PackedVector2Array = _resample_path(path, FRONT_STEP)
		var n: int = pts.size()
		if n < 2:
			continue
		for i in n:
			var t: Vector2 = pts[mini(i + 1, n - 1)] - pts[maxi(i - 1, 0)]
			if t.length() < 0.001:
				continue
			t = t.normalized()
			var nrm := Vector2(-t.y, t.x)
			for side in 2:
				var sid: int = g.war_a if side == 0 else g.war_d
				var dir: Vector2 = _side_dir(g, pts[i], nrm, sid)
				if dir == Vector2.ZERO:
					continue
				var p: Vector2 = _first_valid(g, pts[i], dir, sid, [2.2, 1.6, 1.1])
				if p.x < 0.0:
					continue
				_front_dots.append([g.origin + p * cs, side])
				if side == 0:
					cand_mine.append([pts[i], dir])
				else:
					cand_enemy.append([pts[i], dir])
	_place_rings(g, cand_mine, 0, g.war_a, _rings_mine)
	_place_rings(g, cand_enemy, 1, g.war_d, _rings_enemy)


func _add_edge(ea: PackedInt32Array, eb: PackedInt32Array, adj: Dictionary, a: int, b: int) -> void:
	var e: int = ea.size()
	ea.append(a)
	eb.append(b)
	if not adj.has(a):
		adj[a] = []
	adj[a].append(e)
	if not adj.has(b):
		adj[b] = []
	adj[b].append(e)


func _chain_edges(ea: PackedInt32Array, eb: PackedInt32Array, adj: Dictionary) -> Array:
	var n: int = ea.size()
	var visited := PackedByteArray()
	visited.resize(n)
	var chains: Array = []
	for e in n:
		if visited[e] != 0:
			continue
		visited[e] = 1
		var fwd := PackedInt32Array([ea[e], eb[e]])
		fwd = _extend_chain(fwd, adj, ea, eb, visited)
		var back := PackedInt32Array([ea[e]])
		back = _extend_chain(back, adj, ea, eb, visited)
		back.reverse()
		var full := PackedInt32Array()
		for i in range(back.size() - 1):
			full.append(back[i])
		full.append_array(fwd)
		chains.append(full)
	return chains


func _extend_chain(path: PackedInt32Array, adj: Dictionary, ea: PackedInt32Array, eb: PackedInt32Array, visited: PackedByteArray) -> PackedInt32Array:
	while true:
		var k: int = path[path.size() - 1]
		var found := -1
		var list: Array = adj.get(k, [])
		for ei in list:
			if visited[ei] == 0:
				found = ei
				break
		if found == -1:
			break
		visited[found] = 1
		var nxt: int = eb[found] if ea[found] == k else ea[found]
		path.append(nxt)
	return path


func _smooth_path(path: PackedVector2Array, iters: int) -> PackedVector2Array:
	var cur := path
	for it in iters:
		var nxt := cur.duplicate()
		for i in range(2, cur.size() - 2):
			nxt[i] = (cur[i - 2] + cur[i - 1] + cur[i] + cur[i + 1] + cur[i + 2]) / 5.0
		cur = nxt
	return cur


func _resample_path(path: PackedVector2Array, step: float) -> PackedVector2Array:
	var out := PackedVector2Array()
	if path.size() < 2:
		return out
	out.append(path[0])
	var need := step
	for i in range(path.size() - 1):
		var a: Vector2 = path[i]
		var b: Vector2 = path[i + 1]
		var seg_len: float = a.distance_to(b)
		if seg_len < 0.0001:
			continue
		var t := need
		while t <= seg_len:
			out.append(a.lerp(b, t / seg_len))
			t += step
		need = t - seg_len
	return out


func _cell_ctrl(g, q: Vector2) -> int:
	var x: int = int(floor(q.x))
	var y: int = int(floor(q.y))
	if x < 0 or y < 0 or x >= g.w or y >= g.h:
		return -1
	return g.ctrl[y * g.w + x]


func _side_dir(g, p: Vector2, nrm: Vector2, sid: int) -> Vector2:
	if _cell_ctrl(g, p + nrm * 1.5) == sid:
		return nrm
	if _cell_ctrl(g, p - nrm * 1.5) == sid:
		return -nrm
	return Vector2.ZERO


## Первая точка на расстоянии из списка, которая целиком лежит на территории своей стороны
## (иначе точка не ставится: не заходит в чужую страну и в море).
func _first_valid(g, p: Vector2, dir: Vector2, sid: int, dists: Array) -> Vector2:
	for d in dists:
		var q: Vector2 = p + dir * float(d)
		if _cell_ctrl(g, q) == sid and _cell_ctrl(g, p + dir * float(d) * 0.5) == sid:
			return q
	return Vector2(-1.0, -1.0)


func _place_rings(g, list: Array, side: int, sid: int, count: int) -> void:
	var n: int = list.size()
	if n == 0:
		return
	var want: int = mini(count, maxi(1, int(n / 2)))
	var stride: float = maxf(1.0, float(n) / float(want))
	var f: float = stride * 0.5
	var placed: Array = []
	while int(f) < n and placed.size() < want:
		var e: Array = list[int(f)]
		var q: Vector2 = _first_valid(g, e[0], e[1], sid, [8.0, 6.0, 4.5, 3.2])
		if q.x >= 0.0:
			var ok := true
			for other in placed:
				if q.distance_to(other) < 5.0:
					ok = false
					break
			if ok:
				placed.append(q)
				_front_rings.append([g.origin + q * g.cell, side])
		f += stride


func _draw_front() -> void:
	var inv := 1.0 / zoom
	if zoom >= 0.5:
		for p in _front_cities:
			_front_node.draw_circle(p, 2.6 * inv, Color(1.0, 0.9, 0.1))
	for d in _front_dots:
		var col: Color = COLOR_MINE if d[1] == 0 else COLOR_ENEMY
		_front_node.draw_circle(d[0], 5.6 * inv, COLOR_DARK)
		_front_node.draw_circle(d[0], 4.2 * inv, col)
	for r in _front_rings:
		var col2: Color = COLOR_MINE if r[1] == 0 else COLOR_ENEMY
		_front_node.draw_circle(r[0], 10.0 * inv, COLOR_DARK)
		_front_node.draw_circle(r[0], 7.4 * inv, col2)
		_front_node.draw_circle(r[0], 3.6 * inv, COLOR_DARK)


func base_color(i: int) -> Color:
	return _base_colors[i]


func attach_pixels(grid) -> void:
	pixel_layer = Sprite2D.new()
	pixel_layer.set_script(PixelLayerScript)
	add_child(pixel_layer)
	move_child(pixel_layer, _borders.get_index())
	pixel_layer.setup(grid)
