extends RefCounted
## Войны: обоснование (casus belli), объявление, ход боёв по дням, мир.
## Войну нельзя объявить сразу: сначала нужно обосновать её (JUSTIFY_DAYS дней и деньги).

signal event(text: String)
signal territory_changed   # изменилась официальная принадлежность земель
signal annexed(country_index: int, fraction: float)   # присоединена доля страны
signal eliminated(country_index: int)   # страна полностью захвачена и исчезла с карты

const Fmt = preload("res://scripts/ui/fmt.gd")
const JUSTIFY_DAYS := 30
const JUSTIFY_VALID_DAYS := 180
const JUSTIFY_COST_SHARE := 0.03
const BUDGET_SHARE := 0.4
const DEPTH_PER_DAY := 0.5   # на сколько клеток вглубь продвигается фронт в «день успеха»

var data
var grid
var player := -1
var day := 0

var just_target := -1
var just_left := 0
var just_ready := false
var just_expire := 0

var war_d := -1
var war_start := 0

var player_army_k := -1.0         # численность армии игрока из экономики (тыс.)
var player_quality := 1.0        # обучение и вооружение
var player_mil := 1.0            # множитель силы армии от военных расходов
var player_stab := -1.0         # стабильность игрока из экономики (если задана)
var player_budget_bn := -1.0   # бюджет игрока из экономики (если задан)
var conquests: Array = []   # пары [id победителя, id побеждённой] для сохранения
var _rng := RandomNumberGenerator.new()


func setup(map_data, territory_grid, player_idx: int) -> void:
	data = map_data
	grid = territory_grid
	player = player_idx
	_rng.randomize()


func in_war() -> bool:
	return war_d >= 0


func is_justifying() -> bool:
	return just_target >= 0


func name_of(idx: int) -> String:
	return data.countries[idx]["name_ru"]


func budget_bn(idx: int) -> float:
	if idx == player and player_budget_bn >= 0.0:
		return player_budget_bn
	return float(data.countries[idx]["stats"].get("gdp_bn", 0.0)) * BUDGET_SHARE


func justify_cost_bn() -> float:
	return budget_bn(player) * JUSTIFY_COST_SHARE


func is_neighbor(idx: int) -> bool:
	var ids: Array = data.countries[player].get("neighbors", [])
	return ids.has(data.countries[idx]["id"])


func block_reason(idx: int) -> String:
	if idx == player:
		return "Это ваша страна."
	if not data.countries[idx]["playable"]:
		return "Эта территория недоступна для игры."
	if int(grid.counts[idx]) <= 0:
		return "Это государство уже уничтожено."
	if in_war():
		return "Одновременно можно вести только одну войну."
	if is_justifying() and just_target != idx:
		return "Уже обосновывается другая война."
	if not is_neighbor(idx):
		return "Нет общей сухопутной границы. Морские операции появятся позже."
	return ""


func start_justification(idx: int) -> String:
	var why := block_reason(idx)
	if why != "":
		return why
	if is_justifying():
		return "Обоснование уже идёт."
	var cost := justify_cost_bn()
	if GameState.treasury_bn < cost:
		return "Не хватает денег: нужно %s." % Fmt.money_bn(cost)
	GameState.treasury_bn -= cost
	just_target = idx
	just_left = JUSTIFY_DAYS
	just_ready = false
	event.emit("Начато обоснование войны: %s (%d дн.)" % [name_of(idx), JUSTIFY_DAYS])
	return ""


func cancel_justification() -> void:
	if not is_justifying():
		return
	just_target = -1
	just_ready = false
	event.emit("Обоснование войны отменено")


func declare_war() -> String:
	if in_war():
		return "Уже идёт война."
	if not is_justifying() or not just_ready:
		return "Война ещё не обоснована."
	war_d = just_target
	war_start = day
	just_target = -1
	just_ready = false
	grid.now = day
	grid.begin_war(player, war_d)
	event.emit("Война объявлена: %s против %s" % [name_of(player), name_of(war_d)])
	return ""


func war_days() -> int:
	return day - war_start


func taken_by_player_pct() -> int:
	if not in_war():
		return 0
	return int(100.0 * float(grid.held_a) / maxf(1.0, float(grid.counts[war_d])))


func taken_by_enemy_pct() -> int:
	if not in_war():
		return 0
	return int(100.0 * float(grid.held_d) / maxf(1.0, float(grid.counts[player])))


func strength(idx: int) -> float:
	var st: Dictionary = data.countries[idx]["stats"]
	var army := float(st.get("army_k", 5)) + 20.0
	var industry := float(st.get("industry", 3))
	var stability := float(st.get("stability", 50))
	if idx == player and player_stab >= 0.0:
		stability = player_stab
	var mil := 1.0
	if idx == player:
		mil = player_mil * player_quality
		if player_army_k >= 0.0:
			army = player_army_k + 20.0
	return army * (0.5 + 0.1 * industry) * (0.6 + stability / 250.0) * mil


func on_day(day_count: int) -> void:
	day = day_count
	grid.now = day
	if is_justifying():
		if not just_ready:
			just_left -= 1
			if just_left <= 0:
				just_ready = true
				just_expire = JUSTIFY_VALID_DAYS
				event.emit("Война обоснована: можно объявлять войну (%s)" % name_of(just_target))
		else:
			just_expire -= 1
			if just_expire <= 0:
				var n := name_of(just_target)
				just_target = -1
				just_ready = false
				event.emit("Обоснование войны против %s устарело" % n)
	if in_war():
		_war_day()


func _war_day() -> void:
	# Каждый день успех у одной из сторон: чем сильнее армия, тем чаще побеждает она.
	# При равных силах фронт стоит на месте и лишь колеблется, как в настоящей позиционной войне.
	var sa := strength(player)
	var sd := strength(war_d)
	var ra := sa / (sa + sd)
	var a_wins := _rng.randf() < ra
	var front_len: int = grid.front_a.size() if a_wins else grid.front_d.size()
	var n := int(round(float(front_len) * DEPTH_PER_DAY * _rng.randf_range(0.7, 1.3)))
	if front_len > 0 and n < 1:
		n = 1
	grid.advance_side(a_wins, n, day)
	if grid.front_a.size() == 0 and grid.front_d.size() == 0:
		if grid.held_a >= grid.held_d:
			_conquer(war_d)
		else:
			grid.peace_white()
			event.emit("Война проиграна: враг удерживает больше земель. Установлен белый мир.")
			war_d = -1


## Полная победа: страна капитулирует, её земли и соседи переходят к игроку.
func _conquer(loser: int) -> void:
	var moved: int = grid.capitulate(player, loser)
	annexed.emit(loser, 1.0)
	war_d = -1
	_merge_neighbors(player, loser)
	conquests.append([data.countries[player]["id"], data.countries[loser]["id"]])
	eliminated.emit(loser)
	territory_changed.emit()
	event.emit("%s капитулировала. Вся территория присоединена (%d участков)" % [name_of(loser), moved])


func _merge_neighbors(winner: int, loser: int) -> void:
	var wid: String = data.countries[winner]["id"]
	var lid: String = data.countries[loser]["id"]
	var wn: Array = data.countries[winner]["neighbors"]
	var ln: Array = data.countries[loser]["neighbors"]
	for nid in ln:
		if nid != wid and not wn.has(nid):
			wn.append(nid)
		var ni: int = data.index_of(nid)
		if ni >= 0 and ni != winner:
			var nn: Array = data.countries[ni]["neighbors"]
			nn.erase(lid)
			if not nn.has(wid):
				nn.append(wid)
	wn.erase(lid)
	data.countries[loser]["neighbors"] = []


## mode 0 — белый мир, mode 1 — мир по линии фронта.
func make_peace(mode: int, silent: bool = false) -> void:
	if not in_war():
		return
	var enemy := war_d
	if mode == 1:
		var total_before: float = maxf(1.0, float(grid.counts[enemy]))
		var r: Dictionary = grid.peace_front()
		if int(r["to_a"]) > 0:
			annexed.emit(enemy, float(r["to_a"]) / total_before)
		if not silent:
			event.emit("Мир с %s: получено областей %d, потеряно %d" % [name_of(enemy), r["reg_a"], r["reg_d"]])
		else:
			event.emit("Мирный договор: получено %d, потеряно %d участков" % [r["to_a"], r["to_d"]])
	else:
		grid.peace_white()
		event.emit("Белый мир с %s: все земли возвращены" % name_of(enemy))
	war_d = -1
	territory_changed.emit()


# ---------- сохранение ----------

func to_dict() -> Dictionary:
	var d := {"grid": grid.to_dict(), "conquests": conquests}
	if is_justifying():
		d["just"] = {"target": data.countries[just_target]["id"], "left": just_left, "ready": just_ready, "expire": just_expire}
	if in_war():
		d["war"] = {"d": data.countries[war_d]["id"], "start": war_start}
	return d


func load_dict(d: Dictionary, day_count: int) -> void:
	day = day_count
	grid.now = day
	var enemy := -1
	if d.has("war"):
		enemy = data.index_of(str(d["war"].get("d", "")))
		war_start = int(d["war"].get("start", day))
	grid.load_state(d.get("grid", {}), player if enemy >= 0 else -1, enemy)
	for pair in d.get("conquests", []):
		var wi: int = data.index_of(str(pair[0]))
		var li: int = data.index_of(str(pair[1]))
		if wi >= 0 and li >= 0:
			_merge_neighbors(wi, li)
			grid.handled[li] = true
			conquests.append([str(pair[0]), str(pair[1])])
			eliminated.emit(li)
	if enemy >= 0:
		war_d = enemy
	if d.has("just"):
		var t: int = data.index_of(str(d["just"].get("target", "")))
		if t >= 0:
			just_target = t
			just_left = int(d["just"].get("left", JUSTIFY_DAYS))
			just_ready = bool(d["just"].get("ready", false))
			just_expire = int(d["just"].get("expire", JUSTIFY_VALID_DAYS))
