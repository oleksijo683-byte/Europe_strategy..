extends RefCounted
## Экономика государства игрока (Economy Engine): налоги, расходы, долг, торговля, строительство.
## Все числа игровые и приближённые.

signal event(text: String)

const BUILDINGS := {
	"factory": {"name": "Завод", "cost": 0.0025, "days": 90, "gdp": 0.005, "unemp": 0.25},
	"power": {"name": "Электростанция", "cost": 0.0020, "days": 120, "gdp": 0.003, "unemp": 0.10},
	"road": {"name": "Дороги", "cost": 0.0010, "days": 60, "gdp": 0.002, "unemp": 0.10},
	"rail": {"name": "Железная дорога", "cost": 0.0018, "days": 150, "gdp": 0.0035, "unemp": 0.10},
	"port": {"name": "Порт", "cost": 0.0015, "days": 100, "gdp": 0.003, "unemp": 0.10},
}
const ORDER := ["factory", "power", "road", "rail", "port"]
const MAX_PROJECTS := 3

# Налоговые базы (доля ВВП, к которой применяется ставка)
const INC_BASE := 0.55
const CORP_BASE := 0.30
const VAT_BASE := 0.55
const TRADE_BASE := 0.50
const ADMIN_SHARE := 0.10
const WAR_COST_SHARE := 0.15
const LOAN_STEP := 0.02
const MAX_LVL := 5

const RANGES := {
	"t_income": [0.05, 0.60], "t_corp": [0.05, 0.50], "t_vat": [0.05, 0.35], "t_tariff": [0.0, 0.30],
	"s_social": [0.25, 0.70], "s_mil": [0.02, 0.40], "s_edu": [0.02, 0.25], "s_infra": [0.02, 0.25],
}

var gdp_bn := 0.0
var pop := 0.0
var infl := 2.5
var unemp := 7.0
var stab := 60.0
var base_stab := 60.0
var army_k := 0.0
var industry := 5.0
var growth_bonus := 0.0
var built := {}
var queue: Array = []
var income_m := 0.0
var expense_m := 0.0

# налоги
var t_income := 0.30
var t_corp := 0.25
var t_vat := 0.18
var t_tariff := 0.05
# расходы (доли доходов)
var s_social := 0.50
var s_mil := 0.15
var s_edu := 0.10
var s_infra := 0.10
# финансы
var debt_bn := 0.0
var infl_boost := 0.0
var printed_this_month := false
var policies := {"subsidy": false, "anticorr": false}
var at_war_now := false
# армия: призванные сверх штата (тыс.), уровни обучения и вооружения
var army_extra_k := 0.0
var train_lvl := 0
var equip_lvl := 0


func init_from_stats(st: Dictionary) -> void:
	gdp_bn = float(st.get("gdp_bn", 0.0))
	pop = float(st.get("pop", 0.0))
	base_stab = float(st.get("stability", 60))
	stab = base_stab
	army_k = float(st.get("army_k", 0))
	industry = float(st.get("industry", 5))
	unemp = clampf(12.0 - industry * 0.8, 3.0, 14.0)
	infl = 2.5
	growth_bonus = 0.0
	built = {}
	for t in ORDER:
		built[t] = 0
	queue = []
	t_income = 0.30
	t_corp = 0.25
	t_vat = 0.18
	t_tariff = 0.05
	s_social = 0.50
	s_mil = 0.15
	s_edu = 0.10
	s_infra = 0.10
	debt_bn = 0.0
	infl_boost = 0.0
	printed_this_month = false
	policies = {"subsidy": false, "anticorr": false}
	army_extra_k = 0.0
	train_lvl = 0
	equip_lvl = 0


func get_value(key: String) -> float:
	return float(get(key))


func adjust(key: String, delta: float) -> void:
	if not RANGES.has(key):
		return
	var r: Array = RANGES[key]
	set(key, clampf(snappedf(get_value(key) + delta, 0.01), float(r[0]), float(r[1])))


# ---------- доходы и расходы ----------

func raw_burden() -> float:
	return INC_BASE * t_income + CORP_BASE * t_corp + VAT_BASE * t_vat + TRADE_BASE * t_tariff


func efficiency() -> float:
	var e := 1.0 - maxf(0.0, raw_burden() - 0.40) * 0.8
	if policies.get("anticorr", false):
		e += 0.02
	return e


func revenue_year() -> float:
	return gdp_bn * raw_burden() * efficiency()


func spend_share() -> float:
	return s_social + s_mil + s_edu + s_infra + ADMIN_SHARE


func debt_rate() -> float:
	return 0.03 + clampf(debt_bn / maxf(gdp_bn, 1.0), 0.0, 1.5) * 0.05


func interest_year() -> float:
	return debt_bn * debt_rate()


func policy_cost_year(key: String) -> float:
	if not policies.get(key, false):
		return 0.0
	return gdp_bn * (0.004 if key == "subsidy" else 0.002)


func calc_flows(at_war: bool) -> void:
	at_war_now = at_war
	var rev := revenue_year()
	income_m = rev / 12.0
	var spend := rev * spend_share() + interest_year() + policy_cost_year("subsidy") + policy_cost_year("anticorr")
	spend += army_upkeep_year()
	if at_war:
		spend += rev * WAR_COST_SHARE
	expense_m = spend / 12.0


# ---------- армия ----------

func army_total_k() -> float:
	return army_k + army_extra_k


func army_quality() -> float:
	return (1.0 + 0.08 * float(train_lvl)) * (1.0 + 0.10 * float(equip_lvl))


func army_upkeep_year() -> float:
	return army_extra_k * 0.05 + gdp_bn * 0.0004 * float(train_lvl + equip_lvl)


func recruit_amount() -> float:
	return maxf(1.0, army_k * 0.10)


func recruit_cost() -> float:
	return recruit_amount() * 0.03


func train_cost() -> float:
	return gdp_bn * 0.0015 * float(train_lvl + 1)


func equip_cost() -> float:
	return gdp_bn * 0.0030 * float(equip_lvl + 1)


func equip_need_factories() -> int:
	return equip_lvl


func recruit() -> String:
	if army_extra_k + recruit_amount() > maxf(2.0, army_k * 0.5):
		return "Достигнут предел призыва (+50% к штатной армии)."
	var cost := recruit_cost()
	if GameState.treasury_bn < cost:
		return "Не хватает денег в казне."
	GameState.treasury_bn -= cost
	army_extra_k += recruit_amount()
	unemp += 0.1
	return ""


func upgrade_train() -> String:
	if train_lvl >= MAX_LVL:
		return "Обучение уже на максимуме."
	var cost := train_cost()
	if GameState.treasury_bn < cost:
		return "Не хватает денег в казне."
	GameState.treasury_bn -= cost
	train_lvl += 1
	event.emit("Обучение армии: уровень %d" % train_lvl)
	return ""


func upgrade_equip() -> String:
	if equip_lvl >= MAX_LVL:
		return "Вооружение уже на максимуме."
	if int(built.get("factory", 0)) < equip_need_factories():
		return "Нужно больше заводов (построено %d, нужно %d)." % [int(built.get("factory", 0)), equip_need_factories()]
	var cost := equip_cost()
	if GameState.treasury_bn < cost:
		return "Не хватает денег в казне."
	GameState.treasury_bn -= cost
	equip_lvl += 1
	event.emit("Вооружение армии: уровень %d" % equip_lvl)
	return ""


func mil_factor() -> float:
	return clampf(0.6 + (s_mil / 0.15) * 0.4, 0.6, 1.6)


func in_crisis() -> bool:
	return GameState.treasury_bn < 0.0 or debt_bn > 0.9 * gdp_bn


# ---------- торговля ----------

func export_share(at_war: bool) -> float:
	var s := clampf(0.20 + 0.012 * industry + 0.008 * float(built.get("port", 0)) - (t_tariff - 0.05) * 1.5, 0.08, 0.60)
	return s * (0.7 if at_war else 1.0)


func import_share(at_war: bool) -> float:
	var s := clampf(0.22 - (t_tariff - 0.05) * 1.5, 0.08, 0.50)
	return s * (0.8 if at_war else 1.0)


func exports_bn(at_war: bool) -> float:
	return gdp_bn * export_share(at_war)


func imports_bn(at_war: bool) -> float:
	return gdp_bn * import_share(at_war)


# ---------- финансовые действия ----------

func loan_amount() -> float:
	return gdp_bn * LOAN_STEP


func take_loan() -> String:
	var amt := loan_amount()
	if debt_bn + amt > gdp_bn * 1.2:
		return "Лимит займов исчерпан (120% ВВП)."
	debt_bn += amt
	GameState.treasury_bn += amt
	return ""


func repay_loan() -> String:
	if debt_bn <= 0.001:
		return "Долга нет."
	var amt := minf(debt_bn, loan_amount())
	if GameState.treasury_bn < amt:
		return "Не хватает денег в казне."
	GameState.treasury_bn -= amt
	debt_bn -= amt
	return ""


func print_money() -> String:
	if printed_this_month:
		return "В этом месяце деньги уже печатали."
	GameState.treasury_bn += gdp_bn * 0.01
	infl_boost += 2.0
	printed_this_month = true
	return ""


func set_policy(key: String, value: bool) -> void:
	policies[key] = value


# ---------- строительство ----------

func build_days(t: String) -> int:
	var k := clampf(1.0 - (s_infra - 0.10) * 2.0, 0.6, 1.3)
	return maxi(10, int(round(float(BUILDINGS[t]["days"]) * k)))


func cost_of(t: String) -> float:
	return gdp_bn * float(BUILDINGS[t]["cost"])


func start_build(t: String) -> String:
	if queue.size() >= MAX_PROJECTS:
		return "Все строительные бригады заняты (%d)." % MAX_PROJECTS
	var cost := cost_of(t)
	if GameState.treasury_bn < cost:
		return "Не хватает денег в казне."
	GameState.treasury_bn -= cost
	queue.append({"type": t, "left": build_days(t)})
	event.emit("Начато строительство: %s" % BUILDINGS[t]["name"])
	return ""


func daily() -> void:
	var i := queue.size() - 1
	while i >= 0:
		queue[i]["left"] = int(queue[i]["left"]) - 1
		if int(queue[i]["left"]) <= 0:
			var t: String = queue[i]["type"]
			queue.remove_at(i)
			_complete(t)
		i -= 1


func _complete(t: String) -> void:
	var b: Dictionary = BUILDINGS[t]
	built[t] = int(built.get(t, 0)) + 1
	gdp_bn *= 1.0 + float(b["gdp"])
	growth_bonus += 0.0005
	unemp = maxf(2.0, unemp - float(b["unemp"]))
	event.emit("Построено: %s" % b["name"])


# ---------- месяц ----------

func monthly(at_war: bool) -> void:
	calc_flows(at_war)
	GameState.treasury_bn += income_m - expense_m
	var crisis := in_crisis()

	var g := 0.02 + industry * 0.001 + growth_bonus
	g -= (t_corp - 0.25) * 0.10 + (t_income - 0.30) * 0.05 + (t_tariff - 0.05) * 0.10
	g -= maxf(0.0, raw_burden() - 0.40) * 0.15
	g += (s_edu - 0.10) * 0.10 + (s_infra - 0.10) * 0.08
	if policies.get("subsidy", false):
		g += 0.006
	if at_war:
		g -= 0.03
	if crisis:
		g -= 0.01
	g += (stab - 60.0) / 100.0 * 0.01
	gdp_bn *= 1.0 + g / 12.0
	pop *= 1.0 + 0.002 / 12.0

	var target_infl := 2.5 + (t_vat - 0.18) * 10.0 + (t_tariff - 0.05) * 6.0 + infl_boost
	target_infl += (4.0 if crisis else 0.0) + (2.0 if at_war else 0.0)
	infl += clampf(target_infl - infl, -0.5, 0.5)
	infl_boost = maxf(0.0, infl_boost - 0.4)
	printed_this_month = false

	var factories := float(built.get("factory", 0))
	var others := 0.0
	for t in ORDER:
		if t != "factory":
			others += float(built.get(t, 0))
	var target_unemp := 12.0 - industry * 0.8 - factories * 0.25 - others * 0.1 + (t_corp - 0.25) * 8.0
	target_unemp += (1.5 if at_war else 0.0) - (0.5 if policies.get("subsidy", false) else 0.0)
	target_unemp = clampf(target_unemp, 2.0, 25.0)
	unemp += clampf(target_unemp - unemp, -0.3, 0.3)

	var target_stab := base_stab + (s_social - 0.50) * 40.0 - (t_income - 0.30) * 40.0 - (t_vat - 0.18) * 25.0
	target_stab -= maxf(0.0, raw_burden() - 0.40) * 80.0
	target_stab += 2.0 if policies.get("anticorr", false) else 0.0
	target_stab -= (8.0 if at_war else 0.0) + (10.0 if crisis else 0.0) + maxf(0.0, unemp - 8.0) * 0.8
	stab = clampf(stab + clampf(target_stab - stab, -1.5, 1.5), 0.0, 100.0)


## Присоединённые земли дают часть ВВП (60%: оккупация даёт меньше) и население.
func add_conquered(loser_gdp: float, loser_pop: float, fraction: float) -> void:
	gdp_bn += loser_gdp * fraction * 0.6
	pop += loser_pop * fraction


# ---------- сохранение ----------

func to_dict() -> Dictionary:
	return {
		"gdp_bn": gdp_bn, "pop": pop, "infl": infl, "unemp": unemp, "stab": stab, "base_stab": base_stab,
		"army_k": army_k, "industry": industry, "growth_bonus": growth_bonus, "built": built, "queue": queue,
		"t_income": t_income, "t_corp": t_corp, "t_vat": t_vat, "t_tariff": t_tariff,
		"s_social": s_social, "s_mil": s_mil, "s_edu": s_edu, "s_infra": s_infra,
		"army_extra_k": army_extra_k, "train_lvl": train_lvl, "equip_lvl": equip_lvl,
		"debt_bn": debt_bn, "infl_boost": infl_boost, "printed": printed_this_month, "policies": policies,
	}


func load_dict(d: Dictionary) -> void:
	gdp_bn = float(d.get("gdp_bn", 0.0))
	pop = float(d.get("pop", 0.0))
	infl = float(d.get("infl", 2.5))
	unemp = float(d.get("unemp", 7.0))
	stab = float(d.get("stab", 60.0))
	base_stab = float(d.get("base_stab", 60.0))
	army_k = float(d.get("army_k", 0.0))
	industry = float(d.get("industry", 5.0))
	growth_bonus = float(d.get("growth_bonus", 0.0))
	t_income = float(d.get("t_income", 0.30))
	t_corp = float(d.get("t_corp", 0.25))
	t_vat = float(d.get("t_vat", 0.18))
	t_tariff = float(d.get("t_tariff", 0.05))
	s_social = float(d.get("s_social", 0.50))
	s_mil = float(d.get("s_mil", 0.15))
	s_edu = float(d.get("s_edu", 0.10))
	s_infra = float(d.get("s_infra", 0.10))
	debt_bn = float(d.get("debt_bn", 0.0))
	army_extra_k = float(d.get("army_extra_k", 0.0))
	train_lvl = int(d.get("train_lvl", 0))
	equip_lvl = int(d.get("equip_lvl", 0))
	infl_boost = float(d.get("infl_boost", 0.0))
	printed_this_month = bool(d.get("printed", false))
	var p: Dictionary = d.get("policies", {})
	policies = {"subsidy": bool(p.get("subsidy", false)), "anticorr": bool(p.get("anticorr", false))}
	built = {}
	var b: Dictionary = d.get("built", {})
	for t in ORDER:
		built[t] = int(b.get(t, 0))
	queue = []
	for q in d.get("queue", []):
		queue.append({"type": str(q["type"]), "left": int(q["left"])})
