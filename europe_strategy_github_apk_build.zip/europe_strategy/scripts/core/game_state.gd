extends Node
## Состояние партии (автозагрузка GameState): страна игрока, игровая дата, скорость времени, казна.

signal day_passed
signal month_passed
signal speed_changed
signal before_save   # перед записью сохранения: модули кладут своё состояние в GameState

const START_YEAR := 2026
const START_MONTH := 1
const START_DAY := 1
const SPEEDS := [0, 1, 2, 5, 10]  # дней в секунду

var player_id: String = ""
var year := START_YEAR
var month := START_MONTH
var day := START_DAY
var speed := 0
var treasury_bn := 0.0   # казна, млрд $
var active := false      # время идёт только когда открыт экран игры
var day_count := 0       # дней с начала партии
var war_data: Dictionary = {}  # состояние войн и захваченных территорий
var economy_data: Dictionary = {}  # экономика страны игрока

var _acc := 0.0


func reset() -> void:
	player_id = ""
	year = START_YEAR
	month = START_MONTH
	day = START_DAY
	speed = 0
	treasury_bn = 0.0
	active = false
	day_count = 0
	war_data = {}
	economy_data = {}
	_acc = 0.0


func new_game(country_id: String, start_treasury_bn: float) -> void:
	reset()
	player_id = country_id
	treasury_bn = start_treasury_bn


func set_speed(value: int) -> void:
	speed = value
	speed_changed.emit()


func days_in_month(y: int, m: int) -> int:
	match m:
		2:
			var leap := (y % 4 == 0 and y % 100 != 0) or y % 400 == 0
			return 29 if leap else 28
		4, 6, 9, 11:
			return 30
		_:
			return 31


func _process(delta: float) -> void:
	if not active or speed <= 0:
		return
	_acc += delta * float(speed)
	while _acc >= 1.0:
		_acc -= 1.0
		_advance_day()


func _advance_day() -> void:
	var new_month := false
	day_count += 1
	day += 1
	if day > days_in_month(year, month):
		day = 1
		month += 1
		new_month = true
		if month > 12:
			month = 1
			year += 1
	day_passed.emit()
	if new_month:
		month_passed.emit()
		if GameSettings.autosave_enabled:
			SaveSystem.save_game()


func to_dict() -> Dictionary:
	return {
		"player_id": player_id,
		"year": year, "month": month, "day": day,
		"treasury_bn": treasury_bn,
		"day_count": day_count,
		"war_data": war_data,
		"economy_data": economy_data,
	}


func from_dict(d: Dictionary) -> bool:
	if not d.has("player_id") or str(d["player_id"]) == "":
		return false
	reset()
	player_id = str(d["player_id"])
	year = int(d.get("year", START_YEAR))
	month = clampi(int(d.get("month", START_MONTH)), 1, 12)
	day = clampi(int(d.get("day", START_DAY)), 1, days_in_month(year, month))
	treasury_bn = float(d.get("treasury_bn", 0.0))
	day_count = int(d.get("day_count", 0))
	var wd = d.get("war_data", {})
	war_data = wd if typeof(wd) == TYPE_DICTIONARY else {}
	var ed = d.get("economy_data", {})
	economy_data = ed if typeof(ed) == TYPE_DICTIONARY else {}
	return true
