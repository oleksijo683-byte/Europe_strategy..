extends Node
## Настройки игры (автозагрузка GameSettings). Хранятся в user://settings.cfg

const PATH := "user://settings.cfg"

var quality: int = 1            # 0 низкое, 1 среднее, 2 высокое
var fps_limit: int = 60         # 30 или 60
var hints_enabled: bool = true  # подсказки туториала
var autosave_enabled: bool = true


func _ready() -> void:
	load_settings()
	apply()


func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	quality = int(cfg.get_value("graphics", "quality", quality))
	fps_limit = int(cfg.get_value("graphics", "fps_limit", fps_limit))
	hints_enabled = bool(cfg.get_value("game", "hints_enabled", hints_enabled))
	autosave_enabled = bool(cfg.get_value("game", "autosave_enabled", autosave_enabled))


func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("graphics", "quality", quality)
	cfg.set_value("graphics", "fps_limit", fps_limit)
	cfg.set_value("game", "hints_enabled", hints_enabled)
	cfg.set_value("game", "autosave_enabled", autosave_enabled)
	cfg.save(PATH)


func apply() -> void:
	Engine.max_fps = fps_limit
	var root := get_tree().root
	match quality:
		0:
			root.msaa_2d = Viewport.MSAA_DISABLED
		1:
			root.msaa_2d = Viewport.MSAA_2X
		_:
			root.msaa_2d = Viewport.MSAA_4X
