extends Node
## Сохранения (автозагрузка SaveSystem). Один слот: user://save.json

const SAVE_PATH := "user://save.json"
const VERSION := 1


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


func save_game() -> bool:
	if GameState.player_id == "":
		return false
	GameState.before_save.emit()
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		push_error("Не удалось открыть файл сохранения")
		return false
	f.store_string(JSON.stringify({"version": VERSION, "game": GameState.to_dict()}))
	f.close()
	return true


func load_game() -> bool:
	if not has_save():
		return false
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if typeof(parsed) != TYPE_DICTIONARY or not parsed.has("game"):
		return false
	return GameState.from_dict(parsed["game"])
