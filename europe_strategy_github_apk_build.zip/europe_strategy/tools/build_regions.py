#!/usr/bin/env python3
"""Делит страны на области по картинке tools/regions_map.jpg.
Картинка в проекции LAEA: параметры подобраны по берегам (см. LAEA ниже).
Результат: data/europe_regions.dat. Запуск: python3 tools/build_regions.py
Нужны: numpy, scipy, opencv-python. Сначала должен быть собран data/europe_grid.dat (build_map.py).
"""
import base64, json, math, os
import numpy as np
import cv2
from scipy import ndimage as ndi

HERE = os.path.dirname(os.path.abspath(__file__))
IMG = os.path.join(HERE, "regions_map.jpg")
GRID = os.path.join(HERE, "..", "data", "europe_grid.dat")
OUT = os.path.join(HERE, "..", "data", "europe_regions.dat")
LAEA = [989.403, 408.512, 275.489, 20.081, 55.431]   # масштаб, сдвиг x, сдвиг y, центр долгота, центр широта
SEA = 255
MIN_REGION_PX = 6        # мелкие обломки на картинке считаем линиями
MIN_REGION_CELLS = 6     # мелкие области вливаем в соседние
SPLIT_MIN_CELLS = 150     # страну с одной областью и таким числом клеток делим на несколько
SPLIT_CELLS_PER_REGION = 90
MAX_FILL_DIST = 25       # дальше этого расстояния (в клетках) клетка считается «непокрытой»


def load_grid():
    g = json.load(open(GRID))
    w, h = g["w"], g["h"]
    raw = base64.b64decode(g["rle"])
    own = bytearray()
    for i in range(0, len(raw), 3):
        own += bytes([raw[i]]) * (raw[i + 1] | (raw[i + 2] << 8))
    own = np.frombuffer(bytes(own), dtype=np.uint8).reshape(h, w)
    return g, own


def laea_uv(g, shape):
    h, w = shape
    S = 2500.0
    X = g["ox"] + (np.arange(w) + 0.5) * g["cell"]
    Y = g["oy"] + (np.arange(h) + 0.5) * g["cell"]
    lon = X / S
    lat = 2 * np.arctan(np.exp(-Y / S)) - math.pi / 2
    LON, LAT = np.meshgrid(lon, lat)
    s, tx, ty, l0, f0 = LAEA
    l0, f0 = math.radians(l0), math.radians(f0)
    k = np.sqrt(2 / (1 + np.sin(f0) * np.sin(LAT) + np.cos(f0) * np.cos(LAT) * np.cos(LON - l0)))
    x = k * np.cos(LAT) * np.sin(LON - l0)
    y = k * (np.cos(f0) * np.sin(LAT) - np.sin(f0) * np.cos(LAT) * np.cos(LON - l0))
    return tx + s * x, ty - s * y


def main():
    g, own = load_grid()
    h, w = own.shape
    land = own != SEA

    im = cv2.imread(IMG)[:, :, ::-1].astype(int)
    ih, iw, _ = im.shape
    r, gg, b = im[..., 0], im[..., 1], im[..., 2]
    sea = (b > r + 40) & (b > 200)
    line = (~sea) & (im.min(axis=2) < 232)
    white = (~sea) & (~line)
    lab, n = ndi.label(white)
    areas = np.bincount(lab.ravel())
    small = areas < MIN_REGION_PX
    small[0] = True
    lab[small[lab]] = 0
    print("компонент на картинке:", int((~small).sum()))
    dist, (iy, ix) = ndi.distance_transform_edt(lab == 0, return_indices=True)

    u, v = laea_uv(g, own.shape)
    ui = np.rint(u).astype(int)
    vi = np.rint(v).astype(int)
    valid = (ui >= 0) & (ui < iw) & (vi >= 0) & (vi < ih)
    uc = np.clip(ui, 0, iw - 1)
    vc = np.clip(vi, 0, ih - 1)
    reg = lab[vc, uc].copy()
    near = (reg == 0) & valid
    reg[near] = lab[iy[vc, uc][near], ix[vc, uc][near]]
    reg[(dist[vc, uc] > 8) & (lab[vc, uc] == 0)] = 0
    reg[~valid] = 0
    reg[~land] = 0

    # страна каждой области — по большинству клеток
    country_of = {}
    for lbl in np.unique(reg[reg > 0]):
        owners = own[(reg == lbl) & land]
        country_of[lbl] = int(np.bincount(owners, minlength=256)[:255].argmax())
    cof = np.zeros(lab.max() + 1, dtype=np.int32) - 1
    for lbl, c in country_of.items():
        cof[lbl] = c
    consistent = (reg > 0) & (cof[reg] == own) & land

    # клетки у границ, попавшие не в ту страну, берём у ближайшей «своей» области
    out = np.where(consistent, reg, -1).astype(np.int64)
    uncovered = np.zeros_like(land)
    for c in np.unique(own[land]):
        mc = own == c
        seeds = mc & consistent
        todo = mc & ~consistent
        if not todo.any():
            continue
        if not seeds.any():
            uncovered |= todo
            continue
        dd, (yy, xx) = ndi.distance_transform_edt(~seeds, return_indices=True)
        ok = todo & (dd <= MAX_FILL_DIST)
        out[ok] = reg[yy[ok], xx[ok]]
        uncovered |= todo & ~ok

    # непокрытые куски (вне картинки и т.п.): по одной области на связный участок страны
    next_id = int(max(out.max() + 1, 1))
    for c in np.unique(own[uncovered]):
        m = uncovered & (own == c)
        comp, k = ndi.label(m)
        for j in range(1, k + 1):
            out[comp == j] = next_id
            next_id += 1
    out[~land] = -1

    # последовательные номера, мелкие области вливаем в соседей той же страны
    def relabel(a):
        ids = np.unique(a[a >= 0])
        table = np.full(a.max() + 2, -1, dtype=np.int64)
        table[ids] = np.arange(len(ids))
        res = np.where(a >= 0, table[np.clip(a, 0, None)], -1)
        return res, len(ids)

    out, nreg = relabel(out)
    for _ in range(3):
        counts = np.bincount(out[out >= 0], minlength=nreg)
        tiny = np.nonzero(counts < MIN_REGION_CELLS)[0]
        if len(tiny) == 0:
            break
        for t in tiny:
            m = out == t
            c = int(own[m][0])
            same = (own == c) & (out >= 0) & (out != t) & (counts[np.clip(out, 0, None)] >= MIN_REGION_CELLS)
            if not same.any():
                continue
            dd, (yy, xx) = ndi.distance_transform_edt(~same, return_indices=True)
            out[m] = out[yy[m], xx[m]]
        out, nreg = relabel(out)

    # крупные страны, у которых на картинке всего одна область (например, Молдова), делим на несколько
    from scipy.cluster.vq import kmeans2
    next_label = int(out.max()) + 1
    for c in np.unique(own[land]):
        m = (own == c) & (out >= 0)
        cells = int(m.sum())
        if cells >= SPLIT_MIN_CELLS and len(np.unique(out[m])) == 1:
            k = int(min(8, max(2, round(cells / SPLIT_CELLS_PER_REGION))))
            ys, xs = np.nonzero(m)
            pts = np.stack([xs, ys], axis=1).astype(float)
            _, lab_k = kmeans2(pts, k, minit="++", seed=7)
            for j in range(k):
                sel = lab_k == j
                out[ys[sel], xs[sel]] = next_label + j
            next_label += k
            print("разделена страна", int(c), "клеток", cells, "на", k, "областей")
    out, nreg = relabel(out)

    # описание областей
    regions = []
    per_country = {}
    for rid in range(nreg):
        ys, xs = np.nonzero(out == rid)
        c = int(own[ys[0], xs[0]])
        per_country[c] = per_country.get(c, 0) + 1
        regions.append([c, int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max()), int(len(xs)), per_country[c]])

    # границы между областями одной страны (для рисования)
    same_land = lambda a, b: (a != SEA) & (b != SEA) & (a == b)
    right = (out[:, :-1] != out[:, 1:]) & same_land(own[:, :-1], own[:, 1:]) & (out[:, :-1] >= 0) & (out[:, 1:] >= 0)
    down = (out[:-1, :] != out[1:, :]) & same_land(own[:-1, :], own[1:, :]) & (out[:-1, :] >= 0) & (out[1:, :] >= 0)
    ev = [int(i) for i in (np.nonzero(right)[0] * w + np.nonzero(right)[1])]
    eh = [int(i) for i in (np.nonzero(down)[0] * w + np.nonzero(down)[1])]

    # RLE: 4 байта на отрезок (номер u16, длина u16); «нет области» = 65535
    flat = np.where(out.ravel() >= 0, out.ravel(), 65535).astype(np.uint32)
    runs = bytearray()
    i = 0
    n = len(flat)
    change = np.nonzero(np.diff(flat) != 0)[0] + 1
    starts = np.concatenate(([0], change))
    ends = np.concatenate((change, [n]))
    for s0, e0 in zip(starts, ends):
        val = int(flat[s0])
        length = int(e0 - s0)
        while length > 0:
            m = min(length, 65535)
            runs += bytes([val & 255, val >> 8, m & 255, m >> 8])
            length -= m

    data = {"w": w, "h": h, "n": nreg, "rle": base64.b64encode(bytes(runs)).decode("ascii"),
            "regions": regions, "ev": ev, "eh": eh}
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(data, f, separators=(",", ":"))
    print("областей:", nreg, "файл:", os.path.getsize(OUT) // 1024, "КБ, рёбер:", len(ev) + len(eh))
    return out, own, per_country


if __name__ == "__main__":
    main()
