#!/usr/bin/env python3
"""Готовит карту Европы для игры.
Читает tools/ne_50m_admin_0_countries.geojson, обрезает по рамке, проецирует (Меркатор),
упрощает контуры, режет на треугольники и пишет data/europe_map.json.
Запуск:  python3 tools/build_map.py
"""
import json, math, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from country_data import DATA, FLAGS

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "ne_50m_admin_0_countries.geojson")
OUT = os.path.join(HERE, "..", "data", "europe_map.dat")

LON_MIN, LON_MAX, LAT_MIN, LAT_MAX = -26.0, 62.0, 30.0, 73.0
GRID_CELL = 5.0         # размер пикселя захвата (единицы карты)
SCALE = 2500.0          # единиц карты на радиан
SIMPLIFY = 1.1          # допуск упрощения (единицы карты)
MIN_RING_AREA = 1.5     # мелкие острова-точки отбрасываем
NOT_PLAYABLE = {"ALA", "ALD", "FRO", "GGY", "JEY", "IMN", "VAT"}
MIN_PLAYABLE_AREA = 8.0

# Цвета стран (в духе Hearts of Iron IV). Ключ: код ADM0_A3.
COLORS = {
    "DEU": "#6e7377", "FRA": "#4a78b8", "ITA": "#4c9a58", "GBR": "#c0707a", "ESP": "#d9a441",
    "PRT": "#3d8d7a", "IRL": "#4ea867", "RUS": "#8c2f2a", "UKR": "#c9b24a", "BLR": "#8fa83f",
    "POL": "#cc6a6a", "CZE": "#5aa0b0", "SVK": "#7a6fb0", "HUN": "#7fb05f", "AUT": "#c9a0a8",
    "CHE": "#d0524f", "LIE": "#e0d060", "LUX": "#8b6fb0", "BEL": "#d4b83a", "NLD": "#e08a3c",
    "DNK": "#c25b56", "NOR": "#b86b4a", "SWE": "#3f77a8", "FIN": "#a9c0d6", "EST": "#6aa6c8",
    "LVA": "#a85a7a", "LTU": "#5a9a6a", "ISL": "#6f9fbf", "ROU": "#cf8a4a", "MDA": "#a06fb0",
    "BGR": "#4f9a78", "SRB": "#b8605a", "HRV": "#4a6fa8", "BIH": "#a0a8c0", "MNE": "#c08a5a",
    "ALB": "#b04a60", "MKD": "#d09a50", "KOS": "#7fa0a0", "GRC": "#5aa0d8", "TUR": "#b8a070",
    "SVN": "#4fb0b8", "MLT": "#d05050", "AND": "#d0b060", "MCO": "#c04040", "SMR": "#60a0e0",
}


def project(lon, lat):
    x = math.radians(lon) * SCALE
    y = -math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)) * SCALE
    return (x, y)


def clip_edge(poly, inside, intersect):
    out = []
    if not poly:
        return out
    prev = poly[-1]
    for cur in poly:
        if inside(cur):
            if not inside(prev):
                out.append(intersect(prev, cur))
            out.append(cur)
        elif inside(prev):
            out.append(intersect(prev, cur))
        prev = cur
    return out


def clip_bbox(ring):
    def ix(x0):
        return lambda a, b: (x0, a[1] + (b[1] - a[1]) * (x0 - a[0]) / (b[0] - a[0]))
    def iy(y0):
        return lambda a, b: (a[0] + (b[0] - a[0]) * (y0 - a[1]) / (b[1] - a[1]), y0)
    p = ring
    p = clip_edge(p, lambda q: q[0] >= LON_MIN, ix(LON_MIN))
    p = clip_edge(p, lambda q: q[0] <= LON_MAX, ix(LON_MAX))
    p = clip_edge(p, lambda q: q[1] >= LAT_MIN, iy(LAT_MIN))
    p = clip_edge(p, lambda q: q[1] <= LAT_MAX, iy(LAT_MAX))
    return p


def area_signed(r):
    s = 0.0
    for i in range(len(r)):
        x0, y0 = r[i]
        x1, y1 = r[(i + 1) % len(r)]
        s += x0 * y1 - x1 * y0
    return s / 2.0


def rdp(pts, eps):
    if len(pts) < 3:
        return pts
    keep = [False] * len(pts)
    keep[0] = keep[-1] = True
    stack = [(0, len(pts) - 1)]
    while stack:
        a, b = stack.pop()
        ax, ay = pts[a]
        bx, by = pts[b]
        dx, dy = bx - ax, by - ay
        L = math.hypot(dx, dy)
        dmax, idx = 0.0, -1
        for i in range(a + 1, b):
            px, py = pts[i]
            if L == 0:
                d = math.hypot(px - ax, py - ay)
            else:
                d = abs(dy * (px - ax) - dx * (py - ay)) / L
            if d > dmax:
                dmax, idx = d, i
        if dmax > eps and idx > 0:
            keep[idx] = True
            stack.append((a, idx))
            stack.append((idx, b))
    return [p for p, k in zip(pts, keep) if k]


def simplify_ring(r, eps):
    # делим кольцо на две половины, чтобы концы не «съедались»
    n = len(r)
    if n < 8:
        return r
    h = n // 2
    a = rdp(r[: h + 1], eps)
    b = rdp(r[h:] + [r[0]], eps)
    return a[:-1] + b[:-1]


def dedupe(r):
    out = []
    for p in r:
        if not out or abs(p[0] - out[-1][0]) > 1e-6 or abs(p[1] - out[-1][1]) > 1e-6:
            out.append(p)
    if len(out) > 1 and abs(out[0][0] - out[-1][0]) < 1e-6 and abs(out[0][1] - out[-1][1]) < 1e-6:
        out.pop()
    return out


def cross(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def in_tri(p, a, b, c):
    d1, d2, d3 = cross(a, b, p), cross(b, c, p), cross(c, a, p)
    neg = d1 < -1e-9 or d2 < -1e-9 or d3 < -1e-9
    pos = d1 > 1e-9 or d2 > 1e-9 or d3 > 1e-9
    return not (neg and pos)


def triangulate(pts):
    """Ear clipping. pts: контур без повтора первой точки. Возвращает индексы треугольников."""
    n = len(pts)
    idx = list(range(n))
    if area_signed(pts) < 0:
        idx.reverse()
    tris = []
    guard = 0
    while len(idx) > 3 and guard < 10 * n * n:
        guard += 1
        ear = False
        m = len(idx)
        for k in range(m):
            i0, i1, i2 = idx[(k - 1) % m], idx[k], idx[(k + 1) % m]
            a, b, c = pts[i0], pts[i1], pts[i2]
            if cross(a, b, c) <= 1e-9:
                continue
            ok = True
            for j in idx:
                if j in (i0, i1, i2):
                    continue
                if in_tri(pts[j], a, b, c):
                    ok = False
                    break
            if ok:
                tris.append((i0, i1, i2))
                idx.pop(k)
                ear = True
                break
        if not ear:
            # вырожденная вершина: выкидываем самую «плоскую»
            best = min(range(len(idx)), key=lambda k: abs(cross(pts[idx[k - 1]], pts[idx[k]], pts[idx[(k + 1) % len(idx)]])))
            idx.pop(best)
    if len(idx) == 3 and cross(pts[idx[0]], pts[idx[1]], pts[idx[2]]) > 1e-9:
        tris.append(tuple(idx))
    return tris


def centroid(r):
    a = area_signed(r)
    if abs(a) < 1e-9:
        return r[0]
    cx = cy = 0.0
    for i in range(len(r)):
        x0, y0 = r[i]
        x1, y1 = r[(i + 1) % len(r)]
        f = x0 * y1 - x1 * y0
        cx += (x0 + x1) * f
        cy += (y0 + y1) * f
    return (cx / (6 * a), cy / (6 * a))


def point_in_ring(p, r):
    x, y = p
    inside = False
    j = len(r) - 1
    for i in range(len(r)):
        xi, yi = r[i]
        xj, yj = r[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


def build_grid(countries, bounds):
    """Растеризует страны в сетку пикселей: номер страны в каждой клетке (255 — море)."""
    import base64
    from itertools import groupby
    CELL = GRID_CELL
    x0 = bounds[0] - 2 * CELL
    y0 = bounds[1] - 2 * CELL
    W = int(math.ceil((bounds[2] - bounds[0]) / CELL)) + 5
    H = int(math.ceil((bounds[3] - bounds[1]) / CELL)) + 5
    grid = bytearray([255]) * (W * H)
    for ci, c in enumerate(countries):
        rows = {}
        for r in c["rings"]:
            n = len(r)
            for i in range(n):
                ax, ay = r[i]
                bx, by = r[(i + 1) % n]
                if ay == by:
                    continue
                if ay > by:
                    ax, ay, bx, by = bx, by, ax, ay
                j0 = max(0, int(math.ceil((ay - y0) / CELL - 0.5)))
                j1 = min(H - 1, int(math.ceil((by - y0) / CELL - 0.5)) - 1)
                for j in range(j0, j1 + 1):
                    yc = y0 + (j + 0.5) * CELL
                    rows.setdefault(j, []).append(ax + (bx - ax) * (yc - ay) / (by - ay))
        for j, xs in rows.items():
            xs.sort()
            for k in range(0, len(xs) - 1, 2):
                i0 = max(0, int(math.ceil((xs[k] - x0) / CELL - 0.5)))
                i1 = min(W - 1, int(math.floor((xs[k + 1] - x0) / CELL - 0.5)))
                if i1 >= i0:
                    grid[j * W + i0: j * W + i1 + 1] = bytes([ci]) * (i1 - i0 + 1)
    counts = [0] * len(countries)
    for v in grid:
        if v != 255:
            counts[v] += 1
    playable = [c["playable"] for c in countries]
    pairs = {}
    for j in range(1, H - 1):
        base = j * W
        for i in range(1, W - 1):
            a = grid[base + i]
            if a == 255:
                continue
            for off in (1, W):
                b = grid[base + i + off]
                if b != 255 and b != a and playable[a] and playable[b]:
                    key = (min(a, b), max(a, b))
                    e = pairs.setdefault(key, [0, set()])
                    e[0] += 1
                    e[1].add(base + i)
                    e[1].add(base + i + off)
    runs = bytearray()
    for v, g in groupby(grid):
        n = sum(1 for _ in g)
        while n > 0:
            m = min(n, 65535)
            runs += bytes([v, m & 255, m >> 8])
            n -= m
    out_pairs = {f"{a}-{b}": sorted(e[1]) for (a, b), e in pairs.items() if e[0] >= 3}
    neigh = {i: [] for i in range(len(countries))}
    for (a, b), e in pairs.items():
        if e[0] >= 3:
            neigh[a].append(countries[b]["id"])
            neigh[b].append(countries[a]["id"])
    data = {"cell": CELL, "ox": x0, "oy": y0, "w": W, "h": H,
            "rle": base64.b64encode(bytes(runs)).decode("ascii"), "counts": counts, "pairs": out_pairs}
    return data, neigh, grid, (W, H)


def main():
    data = json.load(open(SRC, encoding="utf-8"))
    countries = []
    for f in data["features"]:
        pr = f["properties"]
        g = f["geometry"]
        polys = g["coordinates"] if g["type"] == "MultiPolygon" else [g["coordinates"]]
        rings = []
        for poly in polys:
            ext = [tuple(c[:2]) for c in poly[0]]
            if ext[0] == ext[-1]:
                ext = ext[:-1]
            lons = [c[0] for c in ext]
            lats = [c[1] for c in ext]
            if max(lons) < LON_MIN or min(lons) > LON_MAX or max(lats) < LAT_MIN or min(lats) > LAT_MAX:
                continue
            c = clip_bbox(ext)
            if len(c) < 3:
                continue
            p = [project(lon, lat) for lon, lat in c]
            p = dedupe(simplify_ring(dedupe(p), SIMPLIFY))
            if len(p) < 3 or abs(area_signed(p)) < MIN_RING_AREA:
                continue
            rings.append(p)
        if not rings:
            continue
        cid = pr["ADM0_A3"]
        playable = (pr["CONTINENT"] == "Europe" or cid == "TUR") and cid not in NOT_PLAYABLE
        total = sum(abs(area_signed(r)) for r in rings)
        if playable and total < MIN_PLAYABLE_AREA:
            playable = False
        countries.append({"id": cid, "name": pr["NAME_EN"] or pr["NAME"], "name_ru": pr.get("NAME_RU") or pr["NAME"],
                          "playable": playable, "area": total, "rings": rings,
                          "lab": (pr.get("LABEL_X"), pr.get("LABEL_Y")),
                          "pop": int(pr.get("POP_EST") or 0), "gdp_md": float(pr.get("GDP_MD") or 0)})

    # метки: берём точку из данных, если она лежит внутри; иначе центр крупнейшего контура
    for c in countries:
        big = max(c["rings"], key=lambda r: abs(area_signed(r)))
        lx, ly = c["lab"]
        pos = None
        if lx is not None and ly is not None and LON_MIN < lx < LON_MAX and LAT_MIN < ly < LAT_MAX:
            q = project(lx, ly)
            if any(point_in_ring(q, r) for r in c["rings"]):
                pos = q
        if pos is None:
            pos = centroid(big)
            if not point_in_ring(pos, big):
                pos = big[0]
        c["label"] = pos

    # соседи (по близким вершинам) и раскраска
    cell = 6.0
    grid = {}
    for ci, c in enumerate(countries):
        for r in c["rings"]:
            for x, y in r:
                grid.setdefault((int(x // cell), int(y // cell)), set()).add(ci)
    adj = {i: {} for i in range(len(countries))}
    for cellk, owners in grid.items():
        for a in owners:
            for b in owners:
                if a < b:
                    adj[a][b] = adj[a].get(b, 0) + 1
                    adj[b][a] = adj[b].get(a, 0) + 1
    palette_n = 8
    order = sorted([i for i, c in enumerate(countries) if c["playable"]], key=lambda i: -len(adj[i]))
    color = {}
    for i in order:
        used = {color[j] for j in adj[i] if j in color and adj[i][j] >= 2}
        color[i] = next((k for k in range(palette_n) if k not in used), len(color) % palette_n)

    # треугольники
    out = {"scale": SCALE, "countries": []}
    allx, ally = [], []
    bad = 0
    for ci, c in enumerate(countries):
        polys = []
        for r in c["rings"]:
            tris = triangulate(r)
            a_tri = sum(abs(cross(r[t[0]], r[t[1]], r[t[2]])) / 2 for t in tris)
            a_ring = abs(area_signed(r))
            if a_ring > 0 and abs(a_tri - a_ring) / a_ring > 0.03:
                bad += 1
                print(f"  предупреждение: {c['id']} площадь треугольников {a_tri:.0f} против {a_ring:.0f}")
            flat = [round(v, 1) for p in r for v in p]
            polys.append({"v": flat, "t": [i for t in tris for i in t]})
            allx += [p[0] for p in r]
            ally += [p[1] for p in r]
        stats = {}
        d = DATA.get(c["id"])
        if d:
            cap_x, cap_y = project(d[2], d[1])
            stats = {"capital": d[0], "cap": [round(cap_x, 1), round(cap_y, 1)], "gov": d[3],
                     "army_k": d[4], "area_km2": d[5], "industry": d[6], "stability": d[7], "bloc": d[8],
                     "pop": c["pop"], "gdp_bn": round(c["gdp_md"] / 1000.0, 1)}
        out["countries"].append({
            "stats": stats, "flag": FLAGS.get(c["id"], {"t": "plain", "c": [c.get("hex") or "#888888"]}),
            "id": c["id"], "name": c["name"], "name_ru": c["name_ru"], "playable": c["playable"],
            "color": color.get(ci, -1), "hex": COLORS.get(c["id"], ""), "area": round(c["area"], 1),
            "label": [round(c["label"][0], 1), round(c["label"][1], 1)], "polys": polys})
    out["bounds"] = [round(min(allx), 1), round(min(ally), 1), round(max(allx), 1), round(max(ally), 1)]
    gdata, neigh, grid, dims = build_grid(countries, out["bounds"])
    for ci, oc in enumerate(out["countries"]):
        oc["neighbors"] = sorted(neigh[ci])
    gpath = os.path.join(os.path.dirname(OUT), "europe_grid.dat")
    with open(gpath, "w", encoding="utf-8") as gf:
        json.dump(gdata, gf, separators=(",", ":"))
    print("сетка:", dims, "файл", os.path.getsize(gpath) // 1024, "КБ, пар границ:", len(gdata["pairs"]))
    with open(os.path.join(HERE, "grid_preview.raw"), "wb") as pf:
        pf.write(bytes(grid))
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, separators=(",", ":"))
    nv = sum(len(p["v"]) // 2 for c in out["countries"] for p in c["polys"])
    nostats = [c["id"] for c in out["countries"] if c["playable"] and not c["stats"]]
    if nostats:
        print("нет данных для:", nostats)
    miss = [c["id"] for c in out["countries"] if c["playable"] and not c["hex"]]
    if miss:
        print("нет цвета для:", miss)
    print(f"стран: {len(out['countries'])}, играбельных: {sum(c['playable'] for c in out['countries'])}, вершин: {nv}, проблем: {bad}")
    print("границы:", out["bounds"], "размер файла:", os.path.getsize(OUT) // 1024, "КБ")


if __name__ == "__main__":
    main()
